<?php
/**
 * Test script to verify reports page connectivity
 * Access this file directly to test the reports functionality
 */

require_once("init/init.php");

echo "<h2>Reports Page Connection Test</h2>";
echo "<hr>";

// Test 1: Database Connection
echo "<h3>Test 1: Database Connection</h3>";
try {
    $pdo = $dbcon->connect();
    echo "✅ <strong>SUCCESS:</strong> Database connection established<br>";
} catch (Exception $e) {
    echo "❌ <strong>FAILED:</strong> " . $e->getMessage() . "<br>";
}

// Test 2: ProfitCalculator Class
echo "<h3>Test 2: ProfitCalculator Class</h3>";
try {
    $profitCalc = new ProfitCalculator();
    echo "✅ <strong>SUCCESS:</strong> ProfitCalculator initialized<br>";
} catch (Exception $e) {
    echo "❌ <strong>FAILED:</strong> " . $e->getMessage() . "<br>";
}

// Test 3: Session Check
echo "<h3>Test 3: Session Status</h3>";
if (isset($_SESSION['LOGGEDIN'])) {
    echo "✅ <strong>SUCCESS:</strong> Session active<br>";
    echo "User: " . htmlspecialchars($_SESSION['LOGGEDIN']['name'] ?? 'Unknown') . "<br>";
    echo "Role: " . htmlspecialchars($_SESSION['LOGGEDIN']['role'] ?? 'Unknown') . "<br>";
} else {
    echo "⚠️ <strong>WARNING:</strong> No active session (login required to access reports)<br>";
}

// Test 4: Orders Table Query
echo "<h3>Test 4: Orders Table Query</h3>";
try {
    $sql = "SELECT COUNT(*) as total FROM orders";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "✅ <strong>SUCCESS:</strong> Orders table accessible<br>";
    echo "Total orders in database: " . $result['total'] . "<br>";
} catch (PDOException $e) {
    echo "❌ <strong>FAILED:</strong> " . $e->getMessage() . "<br>";
}

// Test 5: Invoices Table Query
echo "<h3>Test 5: Invoices Table Query</h3>";
try {
    $sql = "SELECT COUNT(*) as total FROM invoices";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "✅ <strong>SUCCESS:</strong> Invoices table accessible<br>";
    echo "Total invoice items: " . $result['total'] . "<br>";
} catch (PDOException $e) {
    echo "❌ <strong>FAILED:</strong> " . $e->getMessage() . "<br>";
}

// Test 6: Products Table with Buying Price
echo "<h3>Test 6: Products with Buying Price</h3>";
try {
    $sql = "SELECT 
                COUNT(*) as total_products,
                SUM(CASE WHEN buying_price > 0 THEN 1 ELSE 0 END) as with_price,
                SUM(CASE WHEN buying_price = 0 OR buying_price IS NULL THEN 1 ELSE 0 END) as without_price
            FROM products";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "✅ <strong>SUCCESS:</strong> Products table accessible<br>";
    echo "Total products: " . $result['total_products'] . "<br>";
    echo "Products with buying price: " . $result['with_price'] . "<br>";
    echo "Products without buying price: " . $result['without_price'] . "<br>";
} catch (PDOException $e) {
    echo "❌ <strong>FAILED:</strong> " . $e->getMessage() . "<br>";
}

// Test 7: Daily Report Query Test
echo "<h3>Test 7: Daily Report Query Test</h3>";
try {
    $testDate = date('Y-m-d');
    $sql = "SELECT COUNT(*) as total 
            FROM orders o
            WHERE DATE(STR_TO_DATE(o.order_date, '%Y-%m-%d %H:%i:%s')) = :date";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':date', $testDate);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "✅ <strong>SUCCESS:</strong> Daily report query works<br>";
    echo "Orders today (" . $testDate . "): " . $result['total'] . "<br>";
} catch (PDOException $e) {
    echo "❌ <strong>FAILED:</strong> " . $e->getMessage() . "<br>";
}

// Test 8: Navigation Link
echo "<h3>Test 8: Navigation Configuration</h3>";
if (file_exists('common/navbar.php')) {
    $navContent = file_get_contents('common/navbar.php');
    if (strpos($navContent, 'reports.php') !== false) {
        echo "✅ <strong>SUCCESS:</strong> Reports link found in navigation<br>";
    } else {
        echo "❌ <strong>FAILED:</strong> Reports link not found in navigation<br>";
    }
} else {
    echo "❌ <strong>FAILED:</strong> Navigation file not found<br>";
}

// Test 9: Required JavaScript Files
echo "<h3>Test 9: Required JavaScript Files</h3>";
$jsFiles = [
    'js/jquery.min.js',
    'js/jquery.dataTables.min.js',
    'js/dataTables.bootstrap4.min.js',
    'js/dataTables.buttons.min.js',
    'js/buttons.bootstrap4.min.js',
    'js/reports.js'
];

foreach ($jsFiles as $file) {
    if (file_exists($file)) {
        echo "✅ $file exists<br>";
    } else {
        echo "❌ $file missing<br>";
    }
}

// Test 10: Reports Page File
echo "<h3>Test 10: Reports Page File</h3>";
if (file_exists('reports.php')) {
    echo "✅ <strong>SUCCESS:</strong> reports.php exists<br>";
    $fileSize = filesize('reports.php');
    echo "File size: " . number_format($fileSize) . " bytes<br>";
} else {
    echo "❌ <strong>FAILED:</strong> reports.php not found<br>";
}

echo "<hr>";
echo "<h3>Summary</h3>";
echo "<p>All tests completed. If all tests passed, the reports page should be working correctly.</p>";
echo "<p><a href='reports.php' class='btn btn-primary'>Go to Reports Page</a></p>";

// Add styling
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; max-width: 900px; margin: 0 auto; }
    h2 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
    h3 { color: #555; margin-top: 20px; }
    hr { margin: 20px 0; }
    .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; }
    .btn:hover { background: #0056b3; }
</style>";
?>


