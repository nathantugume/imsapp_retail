<?php
require_once("init/init.php");

$pdo = $dbcon->connect();

echo "<h2>Yearly Report Debug</h2>";
echo "<hr>";

// Check order_date format
echo "<h3>Sample order_date values:</h3>";
$sql = "SELECT order_date FROM orders LIMIT 5";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$dates = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<pre>";
print_r($dates);
echo "</pre>";

// Test different date parsing approaches
echo "<h3>Testing date parsing methods:</h3>";

$testYear = date('Y'); // Current year

// Method 1: STR_TO_DATE
echo "<h4>Method 1: Using STR_TO_DATE</h4>";
try {
    $sql = "SELECT COUNT(*) as total, 
            YEAR(STR_TO_DATE(o.order_date, '%Y-%m-%d %H:%i:%s')) as parsed_year
            FROM orders o 
            WHERE YEAR(STR_TO_DATE(o.order_date, '%Y-%m-%d %H:%i:%s')) = :year";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':year', $testYear);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Result: " . print_r($result, true) . "<br>";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}

// Method 2: Direct YEAR function (if order_date is already datetime)
echo "<h4>Method 2: Direct YEAR function</h4>";
try {
    $sql = "SELECT COUNT(*) as total, YEAR(o.order_date) as parsed_year
            FROM orders o 
            WHERE YEAR(o.order_date) = :year";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':year', $testYear);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Result: " . print_r($result, true) . "<br>";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}

// Method 3: LIKE pattern
echo "<h4>Method 3: Using LIKE pattern</h4>";
try {
    $pattern = $testYear . '%';
    $sql = "SELECT COUNT(*) as total
            FROM orders o 
            WHERE o.order_date LIKE :pattern";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':pattern', $pattern);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Result: " . print_r($result, true) . "<br>";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}

// Check all years available
echo "<h3>Available years in database:</h3>";
try {
    $sql = "SELECT DISTINCT SUBSTRING(order_date, 1, 4) as year, COUNT(*) as count
            FROM orders 
            GROUP BY SUBSTRING(order_date, 1, 4)
            ORDER BY year DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $years = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>";
    print_r($years);
    echo "</pre>";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}

// Full yearly query test
echo "<h3>Full Yearly Query Test:</h3>";
try {
    $sql = "SELECT o.invoice_no, o.customer_name, o.order_date,
                   COUNT(i.id) as item_count
            FROM orders o
            LEFT JOIN invoices i ON o.invoice_no = i.invoice_no
            WHERE o.order_date LIKE :year_pattern
            GROUP BY o.invoice_no
            ORDER BY o.order_date DESC
            LIMIT 10";
    $pattern = $testYear . '%';
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':year_pattern', $pattern);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "Found " . count($results) . " orders for year " . $testYear . "<br>";
    echo "<pre>";
    print_r($results);
    echo "</pre>";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}

echo "<style>
    body { font-family: Arial; padding: 20px; }
    h3 { color: #333; margin-top: 20px; }
    h4 { color: #666; margin-top: 10px; }
    pre { background: #f5f5f5; padding: 10px; border-radius: 4px; }
</style>";
?>


