<?php
session_start();

if(!isset($_SESSION['LOGGEDIN'])){
	header("location:login.php?unauth=unauthorized access?");
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>St Jude Drugshop and Cosmetic Centre</title>
		<script src="js/jquery.min.js"></script>
		<script src="js/jqueryjs"></script>
		<script src="js/jquery.dataTables.min.js"></script>
		<script src="js/dataTables.bootsrap4.min.js"></script>

		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
		--><link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css"> 
		
		<!-- SweetAlert2 CSS and JS -->
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
		<!-- Font Awesome for icons -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
		
		<script src="js/bootstrap.js"></script>
		<script src="js/sweetalert-handler.js"></script>
		<script>
		$(document).ready(function() {
   		$('#example').DataTable();
		} )</script>
		<script>
		$(document).ready(function() {
   		$('#sales').DataTable();
		} )</script>
	</head>
<body>
<?php include('common/navbar.php'); ?>

	<div class="row">
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total User</strong></div>
				<div class="panel-body total_user" align="center">
					<!-- <h1>2000</h1> -->
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Category</strong></div>
				<div class="panel-body total_category" align="center">
					<!-- <h1>50</h1> -->
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Brand</strong></div>
				<div class="panel-body total_brand" align="center">
					<!-- <h1>234</h1> -->
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Item in Stock</strong></div>
				<div class="panel-body total_item" align="center">
					<!-- <h1>345</h1> -->
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Order Value</strong></div>
				<div class="panel-body total_order_value" align="center">
					<!-- <h1>12334</h1> -->
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Cash Order Value</strong></div>
				<div class="panel-body cash_value" align="center">
					<!-- <h1>40000</h1> -->
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Total Credit Order Value</strong></div>
				<div class="panel-body credit_value" align="center">
					<!-- <h1>606000</h1> -->
				</div>
			</div>
		</div>
		<hr />
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading" align="center"><strong>Current Stock </strong></div>
				<div class="panel-body" align="center">
					<?php 
						$conn = mysqli_connect('localhost','root','','imsapp');

						$sql = "SELECT * FROM products";
						$sql = mysqli_query($conn,$sql);
						$results = mysqli_fetch_all($sql);
						?>
						<table table id="example" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<td>Product</td><td>Stock status</td><td>Availability</td><td>Date Added</td>
							</thead>
						<tbody>
						<?php 
							$i = 0;						
							foreach($results as $result => $value){
								if(intval($value[4]) > 31){
									$availabality = "in stock";
								}elseif(intval($value[4])<30 && intval($value[4])>1){
									$availabality = "product is running out of stock";
								}elseif(intval($value[4])===0)
								{
									$availabality = "product out of stock";
								}
								echo'<tr><td>'.$value[3].'</td>';
								echo'<td>'.$value[4]." (".$value[6].")".'</td>';
								echo'<td>'.$availabality.'</td>';
								echo'<td>'.$value[8].'</td></tr>';
								$i++;
							}
								
							?>	
						</tbody>	
					</table>		
				</div>
			</div>
		</div>
		<hr />
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading" align="center"><strong>Sales per day</strong></div>
				<div class="panel-body" align="center">
					<?php 
						$conn = mysqli_connect('localhost','root','','imsapp');
						$sql = "SELECT * FROM orders OD LEFT JOIN invoices IC  ON `OD`.`invoice_no`=`IC`.`invoice_no`"; 			
						$sql = mysqli_query($conn,$sql);
						$results = mysqli_fetch_all($sql);
						?>
						<table table id="sales" class="table table-striped table-bordered" style="width:100%">
							<thead>
								<td>Customer Name</td><td>Item</td><td>Quantity</td><td>Amount Paid</td><td>Balance</td><td>Order date</td>
							</thead>
						<tbody>
						<?php 
							foreach($results as $result => $value){
								echo'<tr><td>'.$value[1].'</td>';
								echo'<td>'.$value[13].'</td>';
								echo'<td>'.$value[14].'</td>';
								echo'<td>'.$value[7].'</td>';
								echo'<td>'.$value[8].'</td>';
								echo'<td>'.$value[10].'</td></tr>';
							}
								
							?>	
						</tbody>	
					</table>		
				</div>
			</div>
		</div>
<script src="js/dashboard.js"></script>
<?php include("common/footer.php"); ?>