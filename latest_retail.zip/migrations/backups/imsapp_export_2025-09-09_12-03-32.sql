-- IMS App Database Export
-- Generated: 2025-09-09 12:03:32
-- Export Version: 1.0
-- Compatibility: mysql5.7
-- Charset: utf8mb4
-- Collation: utf8mb4_unicode_ci

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
SET time_zone = "+00:00";
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;

-- Character set and collation settings
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Database Structure
-- --------------------------------------------------------

-- Table structure for table `brands`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `brand_id` int NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `b_status` enum('1','0') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `brands`

-- Table structure for table `categories`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `cat_id` int NOT NULL AUTO_INCREMENT,
  `main_cat` int NOT NULL,
  `category_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('1','0') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `categories`

-- Table structure for table `customer_payments`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `customer_payments`;
CREATE TABLE `customer_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_method` enum('Cash','Credit Card','Bank Transfer') NOT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `customer_payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`invoice_no`) ON DELETE CASCADE,
  CONSTRAINT `customer_payments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `customer_payments`
-- Index: order_id
-- Index: created_by

-- Table structure for table `invoices`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_no` int NOT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_qty` int NOT NULL,
  `price_per_item` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `invoice_no` (`invoice_no`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`invoice_no`) REFERENCES `orders` (`invoice_no`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `invoices`
-- Index: invoice_no

-- Table structure for table `migrations`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` varchar(255) NOT NULL,
  `description` text,
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `migrations`

-- Table structure for table `orders`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `invoice_no` int NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtotal` double NOT NULL,
  `gst` double NOT NULL,
  `discount` double NOT NULL,
  `net_total` double NOT NULL,
  `paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `due` decimal(10,2) NOT NULL DEFAULT '0.00',
  `payment_method` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`invoice_no`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `orders`

-- Table structure for table `products`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `pid` int NOT NULL AUTO_INCREMENT,
  `cat_id` int NOT NULL,
  `brand_id` int NOT NULL,
  `product_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` int NOT NULL,
  `price` double NOT NULL,
  `buying_price` double DEFAULT '0',
  `description` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_status` enum('1','0') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expiry_date` date DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `cat_id` (`cat_id`),
  KEY `brand_id` (`brand_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`cat_id`),
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=438 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `products`
-- Index: cat_id
-- Index: brand_id

-- Table structure for table `stock_reconciliations`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `stock_reconciliations`;
CREATE TABLE `stock_reconciliations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `system_stock` int NOT NULL,
  `physical_count` int NOT NULL,
  `difference` int NOT NULL,
  `reconciliation_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `notes` text,
  `created_by` int DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `stock_reconciliations_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`pid`) ON DELETE CASCADE,
  CONSTRAINT `stock_reconciliations_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_reconciliations_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `stock_reconciliations`
-- Index: product_id
-- Index: created_by
-- Index: approved_by

-- Table structure for table `users`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('Master','User') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('1','0') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vcode` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for table `users`

-- Database Data
-- --------------------------------------------------------

-- Dumping data for table `brands`
-- --------------------------------------------------------

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` (`brand_id`, `brand_name`, `b_status`, `created_at`, `updated_at`) VALUES
(31, 'fanta', 1, '2021-02-28 21:49:09', '2021-02-28 21:49:09'),
(32, 'sprite', 1, '2021-02-28 21:49:21', '2021-02-28 21:49:21'),
(33, 'Amoxikid ', 1, '2025-07-31 17:30:34', '2025-07-31 17:30:34'),
(34, 'KAMADOL', 1, '2025-08-06 15:47:42', '2025-08-06 15:47:42'),
(35, 'DUO-COTEXIN', 1, '2025-08-06 16:15:11', '2025-08-06 16:15:11'),
(36, 'Zepar ', 1, '2025-08-07 19:00:18', '2025-08-07 19:00:18'),
(37, 'Syp Centiper', 1, '2025-08-07 19:15:40', '2025-08-07 19:15:40'),
(38, 'Alzol', 1, '2025-08-07 19:23:23', '2025-08-07 19:23:23'),
(39, 'Alwo', 1, '2025-08-07 19:29:19', '2025-08-07 19:29:19'),
(40, 'Kikverm', 1, '2025-08-07 19:35:49', '2025-08-07 19:35:49'),
(41, 'Rohisol', 1, '2025-08-07 19:41:17', '2025-08-07 19:41:17'),
(42, 'Agotrax', 1, '2025-08-07 19:44:32', '2025-08-07 19:44:32'),
(43, 'X-pel', 1, '2025-08-07 19:50:29', '2025-08-07 19:50:29'),
(44, 'D-ARTEP', 1, '2025-08-09 13:13:27', '2025-08-09 13:13:27'),
(45, 'P-ALAXIN', 1, '2025-08-09 13:24:43', '2025-08-09 13:24:43'),
(46, 'P-ALAXIN TS', 1, '2025-08-09 13:34:34', '2025-08-09 13:34:34'),
(47, 'LONART', 1, '2025-08-09 14:03:48', '2025-08-09 14:03:48'),
(48, 'LARTEM', 1, '2025-08-09 14:07:39', '2025-08-09 14:07:39'),
(49, 'RIDIMOL', 1, '2025-08-09 16:09:01', '2025-08-09 16:09:01'),
(50, 'MALAREN', 1, '2025-08-09 16:11:53', '2025-08-09 16:11:53'),
(51, 'Labesten', 1, '2025-08-09 16:31:50', '2025-08-09 16:31:50'),
(52, 'Labstatin', 1, '2025-08-09 16:38:23', '2025-08-09 16:38:23'),
(53, 'Grisben', 1, '2025-08-09 16:47:16', '2025-08-09 16:47:16'),
(54, 'NYSTAGO', 1, '2025-08-09 16:59:10', '2025-08-09 16:59:10'),
(55, 'GYNOZOL', 1, '2025-08-09 17:04:43', '2025-08-09 17:04:43'),
(56, 'FLUZOLE', 1, '2025-08-09 17:12:41', '2025-08-09 17:12:41'),
(57, 'DREZ V GEL', 1, '2025-08-09 17:18:27', '2025-08-09 17:18:27'),
(58, 'Candid -V GEL', 1, '2025-08-09 17:29:19', '2025-08-09 17:29:19'),
(59, 'MINT-O-COOL', 1, '2025-08-09 17:41:21', '2025-08-09 17:41:21'),
(60, 'LIMZER', 1, '2025-08-09 17:47:40', '2025-08-09 17:47:40'),
(61, 'ACICONE-S', 1, '2025-08-09 17:51:59', '2025-08-09 17:51:59'),
(62, 'OCID', 1, '2025-08-09 18:30:12', '2025-08-09 18:30:12'),
(63, 'RELCER', 1, '2025-08-09 18:41:52', '2025-08-09 18:41:52'),
(64, 'ANTAGIT-DS', 1, '2025-08-09 18:49:05', '2025-08-09 18:49:05'),
(65, 'VISCO', 1, '2025-08-09 18:52:21', '2025-08-09 18:52:21'),
(66, 'CENTACID', 1, '2025-08-09 18:56:24', '2025-08-09 18:56:24'),
(67, 'ALCID', 1, '2025-08-09 19:12:24', '2025-08-09 19:12:24'),
(68, 'JENACID', 1, '2025-08-09 19:14:51', '2025-08-09 19:14:51'),
(69, 'MAAGA', 1, '2025-08-09 19:26:21', '2025-08-09 19:26:21'),
(70, 'DEXONA', 1, '2025-08-10 20:58:57', '2025-08-10 20:58:57'),
(71, 'RENE-CPM', 1, '2025-08-10 21:11:27', '2025-08-10 21:11:27'),
(72, 'KAM PREDESOL', 1, '2025-08-11 14:43:43', '2025-08-11 14:43:43'),
(73, 'CETRIREN', 1, '2025-08-11 14:53:42', '2025-08-11 14:53:42'),
(74, 'PROMETHAZINE', 1, '2025-08-11 14:56:49', '2025-08-11 14:56:49'),
(75, 'LORMAN', 1, '2025-08-11 15:00:33', '2025-08-11 15:00:33'),
(76, 'MOSEDIN', 1, '2025-08-11 15:04:35', '2025-08-11 15:04:35'),
(77, 'EROSTIN', 1, '2025-08-11 15:07:57', '2025-08-11 15:07:57'),
(78, 'CLARINASE', 1, '2025-08-11 15:12:16', '2025-08-11 15:12:16'),
(79, 'RENECAL', 1, '2025-08-11 15:30:05', '2025-08-11 15:30:05'),
(80, 'NAT B', 1, '2025-08-11 15:36:57', '2025-08-11 15:36:57'),
(81, 'PYRI', 1, '2025-08-11 15:44:50', '2025-08-11 15:44:50'),
(82, 'CHARCO', 1, '2025-08-12 17:53:40', '2025-08-12 17:53:40'),
(83, 'AXEL', 1, '2025-08-12 18:03:21', '2025-08-12 18:03:21'),
(84, 'FLAGYL', 1, '2025-08-12 18:08:06', '2025-08-12 18:08:06'),
(85, 'TINOL', 0, '2025-08-12 18:12:20', '2025-08-12 18:12:20'),
(86, 'ANTINAL', 0, '2025-08-12 18:16:04', '2025-08-12 18:16:04'),
(87, 'METROGYL', 1, '2025-08-12 18:21:56', '2025-08-12 18:21:56'),
(88, 'KAMODUIM', 1, '2025-08-12 18:29:39', '2025-08-12 18:29:39'),
(89, 'FLUCAP', 1, '2025-08-14 18:02:37', '2025-08-14 18:02:37'),
(90, 'COLDCAP', 1, '2025-08-14 18:15:51', '2025-08-14 18:15:51'),
(91, 'SOKOFF', 1, '2025-08-14 18:20:52', '2025-08-14 18:20:52'),
(92, 'FEBRICOL', 1, '2025-08-14 18:23:41', '2025-08-14 18:23:41'),
(93, 'CHEWCEE', 1, '2025-08-14 18:26:33', '2025-08-14 18:26:33'),
(94, 'FLUFED', 1, '2025-08-14 18:29:42', '2025-08-14 18:29:42'),
(95, 'SINAREST', 1, '2025-08-14 18:36:52', '2025-08-14 18:36:52'),
(96, 'FLURID', 1, '2025-08-14 18:39:44', '2025-08-14 18:39:44'),
(97, 'COLD AFEX', 1, '2025-08-14 18:41:58', '2025-08-14 18:41:58'),
(98, 'TOFFPLUS', 1, '2025-08-14 18:45:08', '2025-08-14 18:45:08'),
(99, 'AGOPLUS', 1, '2025-08-14 18:47:23', '2025-08-14 18:47:23'),
(100, 'COLDEASE', 1, '2025-08-14 18:50:23', '2025-08-14 18:50:23'),
(101, 'ROFLU', 1, '2025-08-14 18:52:40', '2025-08-14 18:52:40'),
(102, 'APFLU', 1, '2025-08-14 19:00:02', '2025-08-14 19:00:02'),
(103, 'JENAFLU', 1, '2025-08-14 19:02:10', '2025-08-14 19:02:10'),
(104, 'PRITEX JUNIOR', 1, '2025-08-14 19:12:47', '2025-08-14 19:12:47'),
(105, 'PIRITON', 1, '2025-08-15 09:15:36', '2025-08-15 09:15:36'),
(106, 'ISORYN', 1, '2025-08-15 09:26:30', '2025-08-15 09:26:30'),
(107, 'ABNAL', 1, '2025-08-15 09:29:00', '2025-08-15 09:29:00'),
(108, 'PROBETA N', 1, '2025-08-15 09:32:19', '2025-08-15 09:32:19'),
(109, 'CIPROCIN', 1, '2025-08-15 10:00:02', '2025-08-15 10:00:02'),
(110, 'DEXONA E', 1, '2025-08-15 10:05:02', '2025-08-15 10:05:02'),
(111, 'ABGENTA', 1, '2025-08-15 10:07:56', '2025-08-15 10:07:56'),
(112, 'ABCHLOR', 1, '2025-08-15 10:11:25', '2025-08-15 10:11:25'),
(113, 'GROVIT', 1, '2025-08-15 10:18:09', '2025-08-15 10:18:09'),
(114, 'TORACTIN', 1, '2025-08-15 10:23:26', '2025-08-15 10:23:26'),
(115, 'ORAXIN', 1, '2025-08-15 10:27:02', '2025-08-15 10:27:02'),
(116, 'RENIRON', 1, '2025-08-15 10:35:42', '2025-08-15 10:35:42'),
(117, 'HAEMO-FORTE', 1, '2025-08-15 10:40:50', '2025-08-15 10:40:50'),
(118, 'KABUUTI', 1, '2025-08-15 10:47:23', '2025-08-15 10:47:23'),
(119, 'ZECUF', 1, '2025-08-15 14:52:10', '2025-08-15 14:52:10'),
(120, 'JENA', 1, '2025-08-15 14:56:29', '2025-08-15 14:56:29'),
(121, 'PRITEX', 1, '2025-08-15 15:00:03', '2025-08-15 15:00:03'),
(122, 'ASCORIL', 1, '2025-08-15 15:03:37', '2025-08-15 15:03:37'),
(123, 'ACEFYL', 1, '2025-08-15 15:09:44', '2025-08-15 15:09:44'),
(124, 'MUCO', 1, '2025-08-15 15:13:05', '2025-08-15 15:13:05'),
(125, 'CADIPHEN', 1, '2025-08-15 15:17:39', '2025-08-15 15:17:39'),
(126, 'CADISTIN', 1, '2025-08-15 15:19:20', '2025-08-15 15:19:20'),
(127, 'KOFLIN', 1, '2025-08-15 15:21:38', '2025-08-15 15:21:38'),
(128, 'YECO', 1, '2025-08-15 15:23:17', '2025-08-15 15:23:17'),
(129, 'RELEX', 1, '2025-08-15 15:25:41', '2025-08-15 15:25:41'),
(130, 'KOFF OF', 1, '2025-08-15 15:27:27', '2025-08-15 15:27:27'),
(131, 'GOOD MORNING', 1, '2025-08-15 15:29:00', '2025-08-15 15:29:00'),
(132, 'ZEDEX', 1, '2025-08-15 15:32:02', '2025-08-15 15:32:02'),
(133, 'LIBTUS PLUS', 1, '2025-08-15 15:34:31', '2025-08-15 15:34:31'),
(134, 'APIDONE', 1, '2025-08-15 15:37:26', '2025-08-15 15:37:26'),
(135, 'PINKO', 1, '2025-08-15 15:51:27', '2025-08-15 15:51:27'),
(136, 'PRINCESS', 1, '2025-08-15 15:53:52', '2025-08-15 15:53:52'),
(137, 'BONISAN', 1, '2025-08-15 15:55:39', '2025-08-15 15:55:39'),
(138, 'SULPHUR', 1, '2025-08-15 15:59:05', '2025-08-15 15:59:05'),
(139, 'OPTHALAMIC OITMENT', 1, '2025-08-15 16:06:24', '2025-08-15 16:06:24'),
(140, 'CANDIDERM', 1, '2025-08-15 16:08:45', '2025-08-15 16:08:45'),
(141, 'MUPIRICIN', 1, '2025-08-15 16:14:12', '2025-08-15 16:14:12'),
(142, 'ECO-DAX', 1, '2025-08-15 16:15:52', '2025-08-15 16:15:52'),
(143, 'INTAMINE', 1, '2025-08-15 16:17:26', '2025-08-15 16:17:26'),
(144, 'NOSORES', 1, '2025-08-15 16:19:45', '2025-08-15 16:19:45'),
(145, 'NEOLEB', 1, '2025-08-15 16:23:10', '2025-08-15 16:23:10'),
(146, 'UNISTEN', 1, '2025-08-15 16:25:16', '2025-08-15 16:25:16'),
(147, 'FUNGNIL', 1, '2025-08-15 16:28:31', '2025-08-15 16:28:31'),
(148, 'DISPERCAM', 1, '2025-08-15 16:30:07', '2025-08-15 16:30:07'),
(149, 'DICLODAY', 1, '2025-08-15 16:32:09', '2025-08-15 16:32:09'),
(150, 'DRAGON', 1, '2025-08-15 16:35:16', '2025-08-15 16:35:16'),
(151, 'SK-DERM', 1, '2025-08-15 16:38:10', '2025-08-15 16:38:10'),
(152, 'BURNCURE', 1, '2025-08-15 16:42:54', '2025-08-15 16:42:54'),
(153, 'BETADERM', 1, '2025-08-15 16:46:17', '2025-08-15 16:46:17'),
(154, 'NO SCAR', 1, '2025-08-15 16:52:19', '2025-08-15 16:52:19'),
(155, 'DREZ', 1, '2025-08-15 16:54:02', '2025-08-15 16:54:02'),
(156, 'BENZOX', 1, '2025-08-15 16:55:45', '2025-08-15 16:55:45'),
(157, 'LYDIA', 1, '2025-08-15 16:59:42', '2025-08-15 16:59:42'),
(158, 'BACKUP', 1, '2025-08-15 17:04:02', '2025-08-15 17:04:02'),
(159, 'WELL PLAN', 1, '2025-08-15 17:06:02', '2025-08-15 17:06:02'),
(160, 'CONDOMS', '', '2025-08-15 17:09:09', '2025-08-15 17:09:09'),
(161, 'DEPO', 1, '2025-08-15 20:48:29', '2025-08-15 20:48:29'),
(162, 'SONATEC', 1, '2025-08-15 21:25:37', '2025-08-15 21:25:37'),
(163, 'SENSODYN', 1, '2025-08-15 21:27:19', '2025-08-15 21:27:19'),
(164, 'AMACLOREEN', 1, '2025-08-16 12:47:00', '2025-08-16 12:47:00'),
(165, 'HIPEN', 1, '2025-08-16 12:53:37', '2025-08-16 12:53:37'),
(166, 'DOXYLEB', 1, '2025-08-16 13:09:58', '2025-08-16 13:09:58'),
(167, 'AMPICILLIN', 1, '2025-08-16 13:13:32', '2025-08-16 13:13:32'),
(168, 'ACLOX', 1, '2025-08-16 13:29:03', '2025-08-16 13:29:03'),
(169, 'CHLOROMPHENICOL', 1, '2025-08-16 15:20:37', '2025-08-16 15:20:37'),
(170, 'ERYTHROMYCIN', 1, '2025-08-16 15:37:56', '2025-08-16 15:37:56'),
(171, 'CIPROREEN', 1, '2025-08-16 15:42:31', '2025-08-16 15:42:31'),
(172, 'COTRIM', 1, '2025-08-16 15:44:59', '2025-08-16 15:44:59'),
(173, 'PEN V', 1, '2025-08-16 15:51:31', '2025-08-16 15:51:31'),
(174, 'AGONAL', 1, '2025-08-16 15:54:11', '2025-08-16 15:54:11'),
(175, 'ZAHA', 1, '2025-08-16 15:57:39', '2025-08-16 15:57:39'),
(176, 'AZITHRO', 1, '2025-08-16 16:05:00', '2025-08-16 16:05:00'),
(177, 'CEFIXIME', 1, '2025-08-16 16:20:07', '2025-08-16 16:20:07'),
(178, 'AGATON', 1, '2025-08-16 16:24:24', '2025-08-16 16:24:24'),
(179, 'LEVO', 1, '2025-08-16 16:28:32', '2025-08-16 16:28:32'),
(180, 'FLUCAMOX', 1, '2025-08-16 16:30:42', '2025-08-16 16:30:42'),
(181, 'CEFELAXIN', 1, '2025-08-16 16:58:08', '2025-08-16 16:58:08'),
(182, 'PAINKILLERS', 1, '2025-08-16 18:16:11', '2025-08-16 18:16:11'),
(183, 'MEDICAL AND PSYCHA', '', '2025-08-16 21:52:49', '2025-08-16 21:52:49'),
(184, 'PENEGRA', '', '2025-08-17 20:19:46', '2025-08-17 20:19:46'),
(185, 'AGOLAC', 1, '2025-08-17 20:43:20', '2025-08-17 20:43:20'),
(186, 'ORALS', 1, '2025-08-18 12:14:09', '2025-08-18 12:14:09'),
(187, 'LOZENGES', 1, '2025-08-18 12:24:12', '2025-08-18 12:24:12'),
(188, 'OTHERS', 1, '2025-08-18 12:28:27', '2025-08-18 12:28:27'),
(189, 'DEODRANTS', 1, '2025-08-18 15:34:55', '2025-08-18 15:34:55'),
(190, 'SPRAYS AND PERFUME', 1, '2025-08-18 15:47:37', '2025-08-18 15:47:37'),
(191, 'MAKE UP', 1, '2025-08-18 16:13:19', '2025-08-18 16:13:19'),
(192, 'TOOTH PASTES', 1, '2025-08-20 09:56:05', '2025-08-20 09:56:05'),
(193, 'SOAPS AND SHOWER GELS', 1, '2025-08-20 10:11:06', '2025-08-20 10:11:06'),
(194, 'BODY OILS AND VITAMINS', 1, '2025-08-20 12:58:36', '2025-08-20 12:58:36'),
(195, 'LOTIONS', 1, '2025-08-20 13:20:10', '2025-08-20 13:20:10'),
(196, 'BODY CREAMS', 1, '2025-08-20 17:06:15', '2025-08-20 17:06:15'),
(197, 'JELLY', 1, '2025-08-20 20:05:36', '2025-08-20 20:05:36'),
(198, 'HAIR SPRAYS AND OILS', 1, '2025-08-21 09:20:09', '2025-08-21 09:20:09'),
(199, 'BODY SCRUB', 1, '2025-08-21 10:11:13', '2025-08-21 10:11:13');

/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `categories`
-- --------------------------------------------------------

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`cat_id`, `main_cat`, `category_name`, `status`, `created_at`) VALUES
(2, 0, 'Electronics', 1, '2020-04-25 09:04:21'),
(18, 0, 'ANTI-BIOTICS', 1, '2025-07-31 17:19:40'),
(20, 0, 'NSAIDS', 1, '2025-08-06 15:39:03'),
(21, 0, 'ANTI-MALARIALS', 1, '2025-08-06 16:05:14'),
(22, 0, 'ANTI-HELMENTHS', 1, '2025-08-07 18:55:45'),
(23, 0, 'ANTI-FUNGALS', 1, '2025-08-09 16:28:38'),
(24, 0, 'GASTROINTESTINAL MEDICINES', 1, '2025-08-09 17:39:29'),
(25, 0, 'ANTI ACIDS', 1, '2025-08-09 18:39:55'),
(26, 0, 'ANTI-ALLERGICS', 1, '2025-08-10 20:56:55'),
(27, 0, 'VITAMINS AND MINERALS ', 1, '2025-08-11 15:25:41'),
(28, 0, 'ANTIAMOEBIC AND ANTIGIARDIASIS', 1, '2025-08-12 18:01:41'),
(29, 0, 'COLD AND FLU', 1, '2025-08-14 18:01:39'),
(30, 0, 'EYE AND EAR MEDICINES', 1, '2025-08-15 09:25:43'),
(31, 0, 'MULTIVITAMINS', 1, '2025-08-15 10:17:25'),
(32, 0, 'COUGH EXPECTORANTS', 1, '2025-08-15 10:46:09'),
(33, 0, 'GRIPE WATER', 1, '2025-08-15 15:50:31'),
(34, 0, 'CREAMS AND OITMENTS', 1, '2025-08-15 15:58:25'),
(35, 0, 'FAMILY PLANNING', 1, '2025-08-15 16:59:15'),
(36, 0, 'ORAL CARE', 1, '2025-08-15 21:24:56'),
(37, 0, 'MINOR', 1, '2025-08-16 21:51:47'),
(38, 0, 'SILDENAFIL', 1, '2025-08-17 20:18:29'),
(39, 0, 'LAXATIVES', 1, '2025-08-17 20:42:01'),
(40, 0, 'ANTISEPTIC AND DISINFECTANTS', 1, '2025-08-18 12:27:53'),
(41, 0, 'COSMETICS', 1, '2025-08-18 15:33:55'),
(42, 0, 'TestCategory', 1, '2025-08-27 11:36:15'),
(43, 0, 'TestCategoryEnhanced', 1, '2025-08-27 11:39:23'),
(44, 0, 'NewTestCategory', 1, '2025-08-27 11:39:35'),
(45, 0, 'StandardLocationTest', 1, '2025-08-27 12:31:07'),
(46, 0, 'Default', 1, '2025-08-27 18:25:46');

/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `customer_payments`
-- --------------------------------------------------------

LOCK TABLES `customer_payments` WRITE;
/*!40000 ALTER TABLE `customer_payments` DISABLE KEYS */;
INSERT INTO `customer_payments` (`id`, `order_id`, `amount_paid`, `payment_date`, `payment_method`, `notes`, `created_by`) VALUES
(1, 34, 2000.00, '2025-09-08 13:35:00', 'Cash', '', 1),
(2, 34, 2000.00, '2025-09-08 13:35:33', 'Cash', '', 1);

/*!40000 ALTER TABLE `customer_payments` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `invoices`
-- --------------------------------------------------------

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` (`id`, `invoice_no`, `product_name`, `order_qty`, `price_per_item`, `created_at`) VALUES
(52, 21, 'O Codoms', 1, 2000, '2025-08-21 20:08:59'),
(53, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:08:59'),
(54, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:08:59'),
(55, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:08:59'),
(56, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:08:59'),
(57, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:08:59'),
(58, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:08:59'),
(59, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:08:59'),
(60, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:08:59'),
(61, 21, 'Face masks', 3, 15000, '2025-08-21 20:08:59'),
(62, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:08:59'),
(63, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:08:59'),
(64, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:08:59'),
(65, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:08:59'),
(66, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:08:59'),
(67, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:00'),
(68, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:00'),
(69, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:00'),
(70, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:00'),
(71, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:00'),
(72, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:00'),
(73, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:00'),
(74, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:00'),
(75, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:09'),
(76, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:09:09'),
(77, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:09'),
(78, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:09:09'),
(79, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:09:09'),
(80, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:09:09'),
(81, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:09:09'),
(82, 21, 'Face masks', 3, 15000, '2025-08-21 20:09:09'),
(83, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:09:09'),
(84, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:09:09'),
(85, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:09:09'),
(86, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:09:09'),
(87, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:09:09'),
(88, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:09'),
(89, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:09'),
(90, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:09'),
(91, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:09'),
(92, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:09'),
(93, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:09'),
(94, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:09'),
(95, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:09'),
(96, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:10'),
(97, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:09:10'),
(98, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:10'),
(99, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:09:10'),
(100, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:09:10'),
(101, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:09:10'),
(102, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:09:10'),
(103, 21, 'Face masks', 3, 15000, '2025-08-21 20:09:10'),
(104, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:09:10'),
(105, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:09:10'),
(106, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:09:10'),
(107, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:09:10'),
(108, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:09:10'),
(109, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:10'),
(110, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:10'),
(111, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:10'),
(112, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:10'),
(113, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:10'),
(114, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:10'),
(115, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:10'),
(116, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:11'),
(117, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:23'),
(118, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:09:23'),
(119, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:23'),
(120, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:09:23'),
(121, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:09:23'),
(122, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:09:23'),
(123, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:09:23'),
(124, 21, 'Face masks', 3, 15000, '2025-08-21 20:09:23'),
(125, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:09:23'),
(126, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:09:23'),
(127, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:09:23'),
(128, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:09:23'),
(129, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:09:23'),
(130, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:23'),
(131, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:23'),
(132, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:23'),
(133, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:23'),
(134, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:23'),
(135, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:23'),
(136, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:23'),
(137, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:23'),
(138, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:23'),
(139, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:09:23'),
(140, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:23'),
(141, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:09:23'),
(142, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:09:23'),
(143, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:09:23'),
(144, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:09:23'),
(145, 21, 'Face masks', 3, 15000, '2025-08-21 20:09:23'),
(146, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:09:23'),
(147, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:09:23'),
(148, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:09:23'),
(149, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:09:23'),
(150, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:09:23'),
(151, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:23'),
(152, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:24'),
(153, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:24'),
(154, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:24'),
(155, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:24'),
(156, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:24'),
(157, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:24'),
(158, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:24'),
(159, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:25'),
(160, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:09:25'),
(161, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:25'),
(162, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:09:25'),
(163, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:09:25'),
(164, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:09:25'),
(165, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:09:25'),
(166, 21, 'Face masks', 3, 15000, '2025-08-21 20:09:25'),
(167, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:09:25'),
(168, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:09:25'),
(169, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:09:25'),
(170, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:09:25'),
(171, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:09:25'),
(172, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:25'),
(173, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:25'),
(174, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:25'),
(175, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:25'),
(176, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:25'),
(177, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:25'),
(178, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:25'),
(179, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:25'),
(180, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:25'),
(181, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:09:25'),
(182, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:25'),
(183, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:09:25'),
(184, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:09:25'),
(185, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:09:25'),
(186, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:09:25'),
(187, 21, 'Face masks', 3, 15000, '2025-08-21 20:09:25'),
(188, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:09:25'),
(189, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:09:25'),
(190, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:09:25'),
(191, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:09:25'),
(192, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:09:25'),
(193, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:25'),
(194, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:25'),
(195, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:25'),
(196, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:25'),
(197, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:25'),
(198, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:25'),
(199, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:25'),
(200, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:25'),
(201, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:26'),
(202, 21, 'Miconazole and Metronidazole Gel', 3, 15000, '2025-08-21 20:09:26'),
(203, 21, 'Syp Ascoril 180mls', 1, 15000, '2025-08-21 20:09:26'),
(204, 21, 'Drez Oitment', 1, 7000, '2025-08-21 20:09:26'),
(205, 21, 'Dragon Liquid', 2, 5000, '2025-08-21 20:09:26'),
(206, 21, 'Candiderm Cream 15mg', 2, 8000, '2025-08-21 20:09:26'),
(207, 21, 'Burncure cream ', 1, 5000, '2025-08-21 20:09:26'),
(208, 21, 'Face masks', 3, 15000, '2025-08-21 20:09:26'),
(209, 21, 'Tbs Albendazole 400mg', 13, 1000, '2025-08-21 20:09:26'),
(210, 21, 'Tbs Albendazole 200mg', 2, 5000, '2025-08-21 20:09:26'),
(211, 21, 'Tbs Ascorbic acid', 70, 100, '2025-08-21 20:09:26'),
(212, 21, 'Tbs Azithromycin Egypt', 1, 20000, '2025-08-21 20:09:26'),
(213, 21, 'Tbs Loratidine INDIA', 3, 300, '2025-08-21 20:09:26'),
(214, 21, 'Cps Amoxycicillin 250mg', 10, 150, '2025-08-21 20:09:26'),
(215, 21, 'Cps Doxycycline 100mg', 3, 200, '2025-08-21 20:09:26'),
(216, 21, 'Cps Omeprazole 20mg', 10, 200, '2025-08-21 20:09:26'),
(217, 21, 'Cps Coldcap', 12, 300, '2025-08-21 20:09:26'),
(218, 21, 'Rinju Lotion M', 1, 8000, '2025-08-21 20:09:26'),
(219, 21, '55 Medix', 1, 45000, '2025-08-21 20:09:26'),
(220, 21, 'O Codoms', 1, 2000, '2025-08-21 20:09:26'),
(221, 21, 'Tbs Hedex ', 20, 250, '2025-08-21 20:09:26'),
(222, 30, 'Dexona EYE-EAR Drops', 2, 3000, '2025-08-21 21:05:09'),
(223, 30, 'Well plan', 1, 3000, '2025-08-21 21:05:09'),
(224, 30, 'Tbs Duo-cotexin ', 3, 2300, '2025-08-21 21:05:09'),
(225, 31, 'Ridimol', 1, 12000, '2025-08-27 18:27:59'),
(226, 31, 'lusaniya1', 1, 1000, '2025-08-27 21:48:23'),
(227, 33, 'Tbs D-artep ', 1, 14000, '2025-08-28 15:33:53'),
(228, 34, 'Venous Curl Activator M', 1, 8000, '2025-09-08 12:15:47');

/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `migrations`
-- --------------------------------------------------------

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `description`, `applied_at`) VALUES
('001_add_expiry_date_to_products', 'Add expiry_date field to products table', '2025-09-08 15:44:12'),
('002_add_status_to_users', 'Add status field to users table', '2025-09-08 15:45:26'),
('003_create_customer_payments_table', 'Create customer_payments table', '2025-09-08 15:45:26'),
('004_create_stock_reconciliations_table', 'Create stock_reconciliations table', '2025-09-08 18:17:47'),
('005_add_created_at_to_products', 'Add created_at timestamp to products table', '2025-09-08 15:45:26'),
('006_update_orders_payment_fields', 'Ensure orders table has proper payment fields', '2025-09-08 15:45:29');

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `orders`
-- --------------------------------------------------------

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`invoice_no`, `customer_name`, `address`, `subtotal`, `gst`, `discount`, `net_total`, `paid`, `due`, `payment_method`, `order_date`) VALUES
(34, 'test', 'KYENJOJO', 8000, 0, 0, 8000, 6000.00, 2000.00, 'Cash', '08-09-2025');

/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `products`
-- --------------------------------------------------------

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`pid`, `cat_id`, `brand_id`, `product_name`, `stock`, `price`, `buying_price`, `description`, `p_status`, `created_at`, `expiry_date`) VALUES
(4, 4, 22, 'Galalxy Prime', 0, 21999, 0, 'Smart Phone', 1, '2020-05-12 20:07:24', NULL),
(5, 5, 21, 'Play Station 3', 0, 14999, 0, 'nice game', 1, '2020-05-12 20:08:50', NULL),
(12, 18, 33, 'Amoxicillin tablets 125mg', 263, 100, 0, 'ty', 1, '2025-07-31 17:37:27', NULL),
(13, 20, 34, 'Paracetamol Tablets bp250mg', 720, 50, 0, 'pain', 1, '2025-08-06 15:52:51', NULL),
(14, 21, 35, 'Tbs Duo-cotexin ', 6, 2300, 0, 'malaria', 1, '2025-08-06 16:26:03', NULL),
(15, 22, 36, 'Albendazole syp', 3, 5000, 0, 'worms', 1, '2025-08-07 19:04:56', NULL),
(16, 22, 36, 'Tbs Albendazole 200mg', 2, 5000, 0, 'worms', 1, '2025-08-07 19:11:38', NULL),
(17, 22, 37, 'Piperazine Citrate 30mls', 4, 5000, 0, 'De wormer', 1, '2025-08-07 19:21:11', NULL),
(18, 22, 38, 'Tbs Albendazole 400mg', 0, 1000, 0, 'de wormer', 1, '2025-08-07 19:26:57', NULL),
(19, 22, 39, 'Albendazole susp 20mls', 4, 3000, 0, 'de wormer', 1, '2025-08-07 19:32:41', NULL),
(20, 22, 40, 'Mebendazole Susp 30mls', 2, 3000, 0, 'de wormer', 1, '2025-08-07 19:39:36', NULL),
(21, 22, 41, 'Levamisole susp 15mls', 5, 5000, 0, 'de wormer', 1, '2025-08-07 19:43:10', NULL),
(22, 22, 42, 'Tbs Levamisole 40mg', 54, 300, 0, 'de wormer', 1, '2025-08-07 19:46:59', NULL),
(23, 22, 43, 'Tbs Mebendazole 100mg', 90, 100, 0, 'de wormer', 1, '2025-08-07 19:52:18', NULL),
(24, 21, 44, 'Tbs D-artep ', 0, 14000, 0, 'antimalarial', 1, '2025-08-09 13:23:09', NULL),
(25, 21, 45, 'Tbs P-Alaxin', 99, 1666, 0, 'Antimalarial', 1, '2025-08-09 13:32:39', NULL),
(26, 21, 46, 'P alaxin Ts', 0, 18000, 0, 'antimalarial', 1, '2025-08-09 14:01:21', NULL),
(27, 21, 47, 'Artmether lumefantrine bliss', 4, 6000, 0, 'antimalarial', 1, '2025-08-09 14:06:42', NULL),
(28, 21, 48, 'Artmether lumefantrine', 23, 5000, 0, 'antimalarial', 1, '2025-08-09 14:13:40', NULL),
(29, 21, 49, 'Ridimol', 0, 12000, 0, 'antimalarial', 1, '2025-08-09 16:10:33', NULL),
(30, 21, 50, 'Sulphurdoxine pyrametherine', 2, 3000, 0, 'ant malarial', 1, '2025-08-09 16:15:09', NULL),
(31, 23, 51, 'Clotrimmazole pesarry  100mg', 3, 4000, 0, 'vaginal tablets', 1, '2025-08-09 16:34:32', NULL),
(32, 23, 52, 'Nystatin Vaginal Tablets', 2, 5000, 0, 'vaginal tablest', 1, '2025-08-09 16:41:40', NULL),
(33, 23, 53, 'Tbs Griseofulvin 500mg ', 70, 500, 0, 'ringworms', 1, '2025-08-09 16:49:57', NULL),
(34, 23, 54, 'Tbs Nytatin', 90, 300, 0, 'antifungal', 1, '2025-08-09 17:01:25', NULL),
(35, 23, 55, 'Gynazole Egypt', 1, 20000, 0, 'antimycotic', 1, '2025-08-09 17:08:01', NULL),
(36, 23, 56, 'Cps Fluconazole 200mg', 66, 1000, 0, 'antifungal', 1, '2025-08-09 17:17:06', NULL),
(37, 23, 57, 'Miconazole and Metronidazole Gel', 0, 15000, 0, 'vaginal gel', 1, '2025-08-09 17:23:09', NULL),
(38, 23, 58, 'Clotrimazole Vaginal Gel', 1, 15000, 0, 'vaginal gel', 1, '2025-08-09 17:31:52', NULL),
(39, 24, 59, 'Tbs Magnesuim Trisilicate', 630, 50, 0, 'ulcers', 1, '2025-08-09 17:45:51', NULL),
(40, 24, 60, 'Cps Limzer MEGA ', 56, 1500, 0, 'uicers', 1, '2025-08-09 17:50:53', NULL),
(41, 24, 61, 'Tbs Acicone', 22, 1000, 0, 'antacid', 1, '2025-08-09 18:28:50', NULL),
(42, 24, 62, 'Cps Omeprazole 20mg', 182, 200, 0, 'anti ulcer', 1, '2025-08-09 18:36:39', NULL),
(43, 25, 63, 'Syp Relcer 180mls', 3, 13000, 0, 'ulcers', 1, '2025-08-09 18:44:15', NULL),
(44, 25, 63, 'Syp Relcer GEL 100mls', 8000, 3, 0, 'ulcers', 1, '2025-08-09 18:47:13', NULL),
(45, 25, 64, 'Syp Antagit-DS Gel', 2, 10000, 0, 'ulcers', 1, '2025-08-09 18:51:19', NULL),
(46, 25, 65, 'Syp Visco 180mls', 1, 15000, 0, 'ulcers', 1, '2025-08-09 18:53:51', NULL),
(47, 25, 66, 'Syp Centacid 100mls', 1, 6000, 0, 'ulcers', 1, '2025-08-09 18:57:55', NULL),
(48, 25, 67, 'Syp Alcid 160mls', 3, 6000, 0, 'ulcers', 1, '2025-08-09 19:13:56', NULL),
(49, 25, 68, 'Syp Genacid 200mls', 3, 9000, 0, 'anti ulcer', 1, '2025-08-09 19:16:37', NULL),
(50, 25, 69, 'Syp Magnesuim Trisilicate 200mls', 2, 5000, 0, 'anti ulcer', 1, '2025-08-09 19:28:53', NULL),
(51, 26, 70, 'Tbs Dexamethasone ', 445, 100, 0, 'allergy', 1, '2025-08-10 21:02:06', NULL),
(52, 26, 71, 'Tbs Chlorphenamine', 230, 50, 0, 'allergy', 1, '2025-08-10 21:14:36', NULL),
(53, 26, 72, 'Tbs Predisolone', 510, 100, 0, 'anti allergy', 1, '2025-08-11 14:51:35', NULL),
(54, 26, 73, 'Tbs Ctrizine Hydrochloride', 380, 100, 0, 'anti allergy', 1, '2025-08-11 14:55:44', NULL),
(55, 26, 74, 'Tbs Promethazine Hydrochloride', 38, 100, 0, 'anti allergy', 1, '2025-08-11 14:59:12', NULL),
(56, 26, 75, 'Tbs Loratidine INDIA', 59, 300, 0, 'anti allergy', 1, '2025-08-11 15:02:42', NULL),
(57, 26, 76, 'Tbs Mosedin Egypt', 31, 1500, 0, 'anti allergy', 1, '2025-08-11 15:07:02', NULL),
(58, 26, 77, 'Tbs Ebastine-10', 14, 1000, 0, 'anti allergy', 1, '2025-08-11 15:11:16', NULL),
(59, 26, 78, 'Tbs Clarinase', 4, 5000, 0, 'allergy and flu', 1, '2025-08-11 15:14:02', NULL),
(60, 27, 79, 'Tbs Calcuim Lactate', 152, 200, 0, 'vits', 1, '2025-08-11 15:33:18', NULL),
(61, 27, 80, 'Cps Nat B MEGA', 28, 1000, 0, 'Minerals', 1, '2025-08-11 15:39:32', NULL),
(62, 27, 81, 'Tbs Pyrodoxine Hydrochloride', 860, 100, 0, 'mineral', 1, '2025-08-11 15:46:22', NULL),
(63, 24, 82, 'Tbs Activated Charcoal', 240, 300, 0, 'stomach', 1, '2025-08-12 17:56:32', NULL),
(64, 28, 83, 'Tbs Metronidazole 400mg AXCEL', 52, 500, 0, 'Antiinective', 1, '2025-08-12 18:06:39', NULL),
(65, 28, 84, 'Tbs Flagyl 400', 144, 500, 0, 'anti infective', 1, '2025-08-12 18:09:56', NULL),
(66, 28, 85, 'Tbs Tinidazole 500mg', 24, 500, 0, 'anti infective', 1, '2025-08-12 18:14:33', NULL),
(67, 28, 86, 'Cps Nifuroxide 200mg', 36, 1500, 0, 'antieffective', 1, '2025-08-12 18:18:53', NULL),
(68, 28, 87, 'Tbs Metronidazole 200mg', 370, 100, 0, 'antiefective', 1, '2025-08-12 18:23:47', NULL),
(69, 28, 88, 'Cps Loperamide', 50, 100, 0, 'anti diarrhea', 1, '2025-08-12 18:31:45', NULL),
(70, 28, 86, 'Syp Antinal', 1, 15000, 0, 'antidiarrhea', 1, '2025-08-12 18:34:06', NULL),
(71, 28, 87, 'Syp Metronidazole', 4, 5000, 0, 'anti effective', 1, '2025-08-14 17:53:05', NULL),
(72, 29, 89, 'Cps Flucap', 140, 200, 0, 'flu', 1, '2025-08-14 18:15:18', NULL),
(73, 29, 90, 'Cps Coldcap', 50, 300, 0, 'flu', 1, '2025-08-14 18:19:20', NULL),
(74, 29, 91, 'Cps Sokoff', 87, 300, 0, 'flu', 1, '2025-08-14 18:22:50', NULL),
(75, 29, 92, 'Tbs Febricol', 30, 500, 0, 'flu', 1, '2025-08-14 18:25:43', NULL),
(76, 29, 93, 'Tbs Ascorbic acid', 290, 100, 0, 'cold', 1, '2025-08-14 18:29:08', NULL),
(77, 29, 95, 'Tbs Sinarest Forte', 124, 250, 0, 'flu', 1, '2025-08-14 18:38:28', NULL),
(78, 29, 96, 'Tbs Flurid', 192, 250, 0, 'flu', 1, '2025-08-14 18:41:16', NULL),
(79, 29, 97, 'Tbs Coldafex', 162, 250, 0, 'flu', 1, '2025-08-14 18:43:30', NULL),
(80, 29, 98, 'Cps Toffplus', 45, 700, 0, 'cold', 1, '2025-08-14 18:46:46', NULL),
(81, 29, 99, 'Cps Agoplus', 24, 500, 0, 'flu', 1, '2025-08-14 18:49:51', NULL),
(82, 29, 100, 'Cps Coldease', 112, 200, 0, 'flu', 1, '2025-08-14 18:51:37', NULL),
(83, 29, 101, 'Tbs Roflu care', 144, 250, 0, 'flu', 1, '2025-08-14 18:54:12', NULL),
(84, 29, 89, 'Syp Flucap', 2, 7000, 0, 'flu', 1, '2025-08-14 18:55:45', NULL),
(85, 29, 90, 'Syp Coldcap', 1, 8000, 0, 'flu', 1, '2025-08-14 18:56:54', NULL),
(86, 29, 102, 'Syp Apflu', 3, 7000, 0, 'flu', 1, '2025-08-14 19:01:27', NULL),
(87, 29, 103, 'Syp Jenaflu', 3, 8000, 0, 'flu', 1, '2025-08-14 19:04:55', NULL),
(88, 29, 104, 'Syp Pritex Junior', 3, 5000, 0, 'cold', 1, '2025-08-14 19:14:57', NULL),
(89, 29, 105, 'Syp Chlorpheranamine', 4, 3000, 0, 'flu', 1, '2025-08-15 09:17:45', NULL),
(90, 26, 73, 'Syp Cetrizine', 2, 5000, 0, 'allergy', 1, '2025-08-15 09:20:32', NULL),
(91, 30, 106, 'Isoryn Nasol drop', 1, 10000, 0, 'paed', 1, '2025-08-15 09:28:33', NULL),
(92, 30, 107, 'Abanal nasol drop', 2, 3000, 0, 'nasal drop', 1, '2025-08-15 09:31:26', NULL),
(93, 30, 108, 'Probeta-N ', 4, 5000, 0, 'een', 1, '2025-08-15 09:58:07', NULL),
(94, 30, 109, 'Ciprofloxacin Eye Drop', 1, 10000, 0, 'eye', 1, '2025-08-15 10:03:58', NULL),
(95, 30, 110, 'Dexona EYE-EAR Drops', 1, 3000, 0, 'eye ear', 1, '2025-08-15 10:07:11', NULL),
(96, 30, 111, 'Gentamicin Eye-Ear drop', 2, 3000, 0, 'ear eye', 1, '2025-08-15 10:10:25', NULL),
(97, 30, 112, 'Chloramphenicol Ear drops', 1, 4000, 0, 'ear', 1, '2025-08-15 10:13:05', NULL),
(98, 30, 112, 'Chloramphenicol Eye drops', 4, 3000, 0, 'eye', 1, '2025-08-15 10:14:52', NULL),
(99, 31, 113, 'Syp Grovit', 2, 8000, 0, 'multivit', 1, '2025-08-15 10:19:44', NULL),
(100, 31, 113, 'Tbs Grovit', 29, 500, 0, 'appetite', 1, '2025-08-15 10:22:34', NULL),
(101, 31, 114, 'Tbs Toractin', 115, 100, 0, 'appetite', 1, '2025-08-15 10:24:50', NULL),
(102, 31, 114, 'Syp Toractin', 3, 6000, 0, 'apetite', 1, '2025-08-15 10:26:14', NULL),
(103, 31, 115, 'Syp Oraxin 100mls', 2, 7000, 0, 'apetite', 1, '2025-08-15 10:31:04', NULL),
(104, 31, 115, 'Syp Oraxin 200mls', 1, 13000, 0, 'appetite', 1, '2025-08-15 10:34:56', NULL),
(105, 31, 116, 'Syp Reniron 100mls', 2, 7000, 0, 'apet', 1, '2025-08-15 10:37:14', NULL),
(106, 31, 117, 'Syp Haemoforte100mls', 1, 7000, 0, 'multivit', 1, '2025-08-15 10:43:59', NULL),
(107, 32, 118, 'Syp Kabuuti', 6, 5000, 0, 'cough', 1, '2025-08-15 10:50:24', NULL),
(108, 32, 119, 'Syp Zecuf 100mls', 2, 6000, 0, 'cough', 1, '2025-08-15 14:55:28', NULL),
(109, 32, 120, 'Syp Jenacof DS', 4, 70000, 0, 'flu and cough', 1, '2025-08-15 14:59:16', NULL),
(110, 32, 121, 'Syp Pritex Codeine', 2, 10000, 0, 'cough', 1, '2025-08-15 15:01:42', NULL),
(111, 32, 121, 'Syp Pritex Baby', 2, 5000, 0, 'cough', 1, '2025-08-15 15:03:07', NULL),
(112, 32, 122, 'Syp Ascoril 180mls', 0, 15000, 0, 'cough', 1, '2025-08-15 15:05:18', NULL),
(113, 32, 122, 'Syp Ascoril 100mls', 1, 9000, 0, 'cough', 1, '2025-08-15 15:07:33', NULL),
(114, 32, 123, 'Syp Acefyl 100mls', 1, 100, 0, 'cough', 1, '2025-08-15 15:11:05', NULL),
(115, 32, 124, 'Syp Mucolex 100mls', 1, 7000, 0, 'cough', 1, '2025-08-15 15:15:17', NULL),
(116, 32, 124, 'Syp Muco-asthalin 100mls', 1, 8000, 0, 'cough', 1, '2025-08-15 15:16:44', NULL),
(117, 32, 125, 'Syp Cadiphen 100mls', 1, 10000, 0, 'cough', 1, '2025-08-15 15:18:57', NULL),
(118, 32, 126, 'Syp Cadistin 100mls', 1, 6000, 0, 'cough', 1, '2025-08-15 15:21:02', NULL),
(119, 32, 127, 'Syp Cough Linctus', 1, 4000, 0, 'cough', 1, '2025-08-15 15:22:43', NULL),
(120, 32, 128, 'Syp Yeco cough dr', 2, 5000, 0, 'cough', 1, '2025-08-15 15:25:15', NULL),
(121, 32, 129, 'Syp Relex 100mls', 1, 7000, 0, 'cough', 1, '2025-08-15 15:26:47', NULL),
(122, 32, 130, 'Syp Koff-off', 1, 5000, 0, 'cough', 1, '2025-08-15 15:28:27', NULL),
(123, 32, 131, 'Syp Goodmorning 100mls', 2, 5000, 0, 'cough', 1, '2025-08-15 15:30:03', NULL),
(124, 32, 132, 'Syp Zedex 100mls', 1, 7000, 0, 'cough', 1, '2025-08-15 15:33:42', NULL),
(125, 32, 133, 'Syp Libitus Plus', 1, 7000, 0, 'cough', 1, '2025-08-15 15:36:46', NULL),
(126, 32, 134, 'Syp Apidone', 1, 28000, 0, 'cough', 1, '2025-08-15 15:38:33', NULL),
(127, 33, 135, 'Syp Pinko', 2, 8000, 0, 'collic', 1, '2025-08-15 15:53:15', NULL),
(128, 33, 136, 'Syp Princess', 2, 5000, 0, 'collic', 1, '2025-08-15 15:55:08', NULL),
(129, 33, 137, 'Syp Bonnisan', 2, 15000, 0, 'collic', 1, '2025-08-15 15:56:53', NULL),
(130, 34, 138, 'Sulfur Oitment', 5, 5000, 0, 'scabicide', 1, '2025-08-15 16:03:53', NULL),
(131, 34, 139, 'Tetracycline opthalamic oitment', 16, 2000, 0, 'eye', 1, '2025-08-15 16:08:11', NULL),
(132, 34, 140, 'Candiderm Cream 15mg', 2, 8000, 0, 'steroid', 1, '2025-08-15 16:10:58', NULL),
(133, 34, 141, 'Mupiricin oitment', 1, 15000, 0, 'fungal', 1, '2025-08-15 16:15:16', NULL),
(134, 34, 142, 'Eco-dax Cream 15mg', 2, 5000, 0, 'steriod', 1, '2025-08-15 16:17:03', NULL),
(135, 34, 143, 'Intamine Cream25mg', 5, 5000, 0, 'anti histamine', 1, '2025-08-15 16:18:51', NULL),
(136, 34, 144, 'No sores gel 10mg ', 1, 6000, 0, 'mouth ulcer', 1, '2025-08-15 16:22:20', NULL),
(137, 34, 145, 'Neomycin Sulphate oitment 15mg', 2, 5000, 0, 'anti bacterial', 1, '2025-08-15 16:24:44', NULL),
(138, 34, 146, 'Unisten 2omg', 3, 4000, 0, 'antifungal', 1, '2025-08-15 16:27:59', NULL),
(139, 34, 147, 'Fungnil Cream 20mg', 3, 5000, 0, 'antifungal', 1, '2025-08-15 16:29:34', NULL),
(140, 34, 148, 'Piroxicam GEL 15mg', 3, 15000, 0, 'pain', 1, '2025-08-15 16:31:31', NULL),
(141, 34, 149, 'Dicloday cream 30mg', 5, 5000, 0, 'pain', 1, '2025-08-15 16:34:47', NULL),
(142, 34, 150, 'Dragon Liquid', 0, 5000, 0, 'pain', 1, '2025-08-15 16:36:17', NULL),
(143, 34, 150, 'Dragon balm', 3, 3000, 0, 'pain', 1, '2025-08-15 16:37:42', NULL),
(144, 34, 151, 'Skderm cream 30mg', 4, 5000, 0, 'antiba ', 1, '2025-08-15 16:41:14', NULL),
(145, 34, 151, 'Skderm cream 15mg', 7, 4000, 0, 'anti bac', 1, '2025-08-15 16:42:22', NULL),
(146, 34, 152, 'Burncure cream ', 2, 5000, 0, 'burn', 1, '2025-08-15 16:45:16', NULL),
(147, 34, 153, 'Betamethasone 15mg', 2, 5000, 0, 'anti bacterial', 1, '2025-08-15 16:49:58', NULL),
(148, 34, 154, 'No Scar cream', 2, 10000, 0, 'scars', 1, '2025-08-15 16:53:24', NULL),
(149, 34, 155, 'Drez Oitment', 0, 7000, 0, 'wounds', 1, '2025-08-15 16:55:08', NULL),
(150, 34, 156, 'Benzox 5 Gel', 2, 8000, 0, 'acne', 1, '2025-08-15 16:57:07', NULL),
(151, 35, 157, 'Lydia', 21, 5000, 0, 'post pill', 1, '2025-08-15 17:02:05', NULL),
(152, 35, 158, 'Backup ', 7, 8000, 0, 'postpill', 1, '2025-08-15 17:05:34', NULL),
(153, 35, 159, 'Well plan', 7, 3000, 0, 'fp', 1, '2025-08-15 17:08:42', NULL),
(154, 35, 160, 'Rough Rider', 2, 15000, 0, 'fp', 1, '2025-08-15 17:10:07', NULL),
(155, 35, 160, 'MOODS', 5, 8000, 0, 'FP', 1, '2025-08-15 17:13:00', NULL),
(156, 35, 160, 'Kiss C', 19, 2000, 0, 'fp', 1, '2025-08-15 19:52:38', NULL),
(157, 35, 160, 'Life guard', 9, 2000, 0, 'fp', 1, '2025-08-15 20:41:54', NULL),
(158, 35, 160, 'Trust', 14, 2000, 0, 'fp', 1, '2025-08-15 20:47:42', NULL),
(159, 35, 161, 'Depo', 24, 5000, 0, 'fp', 1, '2025-08-15 21:24:08', NULL),
(160, 36, 162, 'Sonatec Mouth Wash', 1, 15000, 0, 'oral c', 1, '2025-08-15 21:26:45', NULL),
(161, 36, 163, 'Sensodyn mix 75mls', 6, 15000, 0, 'oralc', 1, '2025-08-15 21:29:41', NULL),
(162, 36, 163, 'Sesodyn Rapid Action', 1, 2, 0, 'oral c', 1, '2025-08-15 21:30:53', NULL),
(163, 36, 163, 'Sensodyn mix 40mls', 3, 8000, 0, 'oral c', 1, '2025-08-15 21:34:04', NULL),
(164, 18, 33, 'Amoxikid 250mg', 595, 200, 0, 'cough', 1, '2025-08-16 12:45:58', NULL),
(165, 18, 164, 'Cps Ampiclox 250mg', 382, 300, 0, 'ant b', 1, '2025-08-16 12:48:15', NULL),
(166, 18, 164, 'Syp Ampiclox 100mls', 2, 5000, 0, 'cogh', 1, '2025-08-16 12:50:02', NULL),
(167, 18, 165, 'Cps Amoxycicillin 250mg', 269, 150, 0, 'fg', 1, '2025-08-16 13:06:19', NULL),
(168, 18, 165, 'Syp Amoxicillin 100mls', 4, 3000, 0, 'coug', 1, '2025-08-16 13:08:40', NULL),
(169, 18, 166, 'Cps Doxycycline 100mg', 200, 200, 0, 'rt', 1, '2025-08-16 13:12:22', NULL),
(170, 18, 167, 'Cps Ampicillin 250mg', 7, 200, 0, 'fy', 1, '2025-08-16 13:18:55', NULL),
(171, 18, 167, 'Syp Ampicillin 100mls', 2, 5000, 0, 'coug', 1, '2025-08-16 13:26:26', NULL),
(172, 18, 168, 'Cps Cloxacillin 250mg', 145, 200, 0, 'cogh', 1, '2025-08-16 13:33:00', NULL),
(173, 18, 169, 'Cps Chloromphenicol 250mg', 67, 250, 0, 'ant bio', 1, '2025-08-16 15:22:08', NULL),
(174, 18, 169, 'Syp Chloromphenicol 100mls', 2, 6000, 0, 'cough', 1, '2025-08-16 15:33:23', NULL),
(175, 18, 170, 'Tbs Erythromycin 250mg', 95, 250, 0, 'antibio', 1, '2025-08-16 15:39:21', NULL),
(176, 18, 170, 'Syp Erythromycin 100mls', 3, 6000, 0, 'cof', 1, '2025-08-16 15:41:30', NULL),
(177, 18, 171, 'Tbs Ciprofloxacin 500mg', 117, 300, 0, 'y', 1, '2025-08-16 15:44:15', NULL),
(178, 18, 172, 'Tbs Co-trimaxazole 960mg', 35, 200, 0, 'gh', 1, '2025-08-16 15:47:39', NULL),
(179, 18, 172, 'Tbs Co-trimaxazole 480mg', 275, 100, 0, 'koff', 1, '2025-08-16 15:48:51', NULL),
(180, 18, 172, 'Syp Co-trimaxazole', 1, 3000, 0, 'cof', 1, '2025-08-16 15:50:38', NULL),
(181, 18, 173, 'Tbs Pen V 250mg', 140, 200, 0, 'antb', 1, '2025-08-16 15:52:54', NULL),
(182, 18, 174, 'Tbs Nalidixic 500mg', 81, 500, 0, 'hu', 1, '2025-08-16 15:56:02', NULL),
(183, 18, 175, 'Tbs Azithromycin Zaha 500mg', 6, 8000, 0, 'couh', 1, '2025-08-16 16:00:04', NULL),
(184, 18, 175, 'Syp Zaha 15mls', 4, 8000, 0, 'antib', 1, '2025-08-16 16:01:51', NULL),
(185, 18, 176, 'Tbs Azithromycin uk 500mg ', 2, 15000, 0, 'ant b', 1, '2025-08-16 16:07:16', NULL),
(186, 18, 176, 'Tbs Azithromycin Egypt', 0, 20000, 0, 'antib', 1, '2025-08-16 16:09:18', NULL),
(187, 18, 175, 'Tbs Azithromycin India', 7, 5000, 0, 'kof', 1, '2025-08-16 16:13:09', NULL),
(188, 18, 176, 'Syp Azileb 15mls', 3, 5000, 0, 'ant b', 1, '2025-08-16 16:16:10', NULL),
(189, 18, 176, 'Tbs Azithromycin 250mg india', 3, 6000, 0, 'cof', 1, '2025-08-16 16:19:38', NULL),
(190, 18, 177, 'Cps Cefixime 400mg', 53, 2000, 0, 'cof', 1, '2025-08-16 16:22:25', NULL),
(191, 18, 177, 'Tbs Cefixime 200mg', 10, 1000, 0, 'kof', 1, '2025-08-16 16:23:21', NULL),
(192, 18, 178, 'Tbs Nitrofrontoin 100mg', 20, 200, 0, 'kof', 1, '2025-08-16 16:26:25', NULL),
(193, 18, 179, 'Tbs Levofloxacin 500mg', 5, 2000, 0, 'uti', 1, '2025-08-16 16:29:59', NULL),
(194, 18, 180, 'Cps Flucamox 500mg', 6, 2000, 0, 'hy', 1, '2025-08-16 16:33:17', NULL),
(195, 18, 177, 'Syp Cefixime 100mls', 1, 15000, 0, 'rr', 1, '2025-08-16 16:51:32', NULL),
(196, 18, 181, 'Syp Cefelaxin 100mls', 2, 7000, 0, 'ty', 1, '2025-08-16 16:59:20', NULL),
(197, 35, 160, 'O Codoms', 14, 2000, 0, 'fp', 1, '2025-08-16 17:03:43', NULL),
(198, 18, 182, 'Tbs Painex', 94, 250, 0, 'pain', 1, '2025-08-16 18:17:22', NULL),
(199, 20, 182, 'PIC', 126, 250, 0, 'PAIN', 1, '2025-08-16 18:28:08', NULL),
(200, 20, 182, 'Tbs Hedex ', 10, 250, 0, 'pain', 1, '2025-08-16 18:29:57', NULL),
(201, 20, 182, 'Tbs Panadol Advance', 8, 250, 0, 'pain', 1, '2025-08-16 18:31:47', NULL),
(202, 20, 182, 'Tbs Ibupar', 38, 500, 0, 'pain', 1, '2025-08-16 18:46:04', NULL),
(203, 20, 182, 'Tbs Extradol ', 44, 250, 0, 'pain', 1, '2025-08-16 18:50:11', NULL),
(204, 20, 182, 'Tbs Hedaid', 18, 250, 0, 'pain', 1, '2025-08-16 18:51:21', NULL),
(205, 20, 182, 'Tbs Hedon', 26, 250, 0, 'pain', 1, '2025-08-16 18:52:38', NULL),
(206, 20, 182, 'Tbs Ibuprofen 400mg', 85, 100, 0, 'pain', 1, '2025-08-16 18:56:37', NULL),
(207, 20, 182, 'Tbs Dynapar', 134, 300, 0, 'pain', 1, '2025-08-16 18:58:05', NULL),
(208, 20, 182, 'Tbs Dentamol', 83, 500, 0, 'pain', 1, '2025-08-16 18:59:16', NULL),
(209, 20, 182, 'Cps Piroxicam', 490, 100, 0, 'pain', 1, '2025-08-16 19:01:40', NULL),
(210, 20, 182, 'Tbs Diclofanac 50mg', 140, 50, 0, 'pain', 1, '2025-08-16 19:03:48', NULL),
(211, 20, 182, 'Cps Indometacin ', 179, 100, 0, 'pain', 1, '2025-08-16 19:05:02', NULL),
(212, 20, 182, 'Tbs Curamol', 20, 250, 0, 'pain', 1, '2025-08-16 19:09:10', NULL),
(213, 20, 182, 'Tbs Mefanamic acid', 42, 500, 0, 'pain', 1, '2025-08-16 19:10:41', NULL),
(214, 20, 182, 'Cps Gofen', 33, 1000, 0, 'pain', 1, '2025-08-16 19:12:50', NULL),
(215, 20, 182, 'Tbs ibuprofen Denk', 25, 1000, 0, 'pain', 1, '2025-08-16 19:14:12', NULL),
(216, 20, 182, 'Tbs Myospaz', 82, 1000, 0, 'pain', 1, '2025-08-16 19:15:39', NULL),
(217, 20, 182, 'Tbs Trap', 100, 500, 0, 'pain', 1, '2025-08-16 19:53:49', NULL),
(218, 20, 182, 'Tbs PA 12', 74, 1000, 0, 'pain', 1, '2025-08-16 19:56:20', NULL),
(219, 20, 182, 'Tbs Biospa', 90, 500, 0, 'pain', 1, '2025-08-16 20:27:10', NULL),
(220, 20, 182, 'Tbs Aceclafanac 100mg', 36, 500, 0, 'pain', 1, '2025-08-16 20:28:26', NULL),
(221, 20, 182, 'Tbs Brutefalam 90mg', 12, 2000, 0, 'pain', 1, '2025-08-16 20:29:41', NULL),
(222, 20, 182, 'Tbs Neuroton', 20, 1000, 0, 'pain', 1, '2025-08-16 20:30:45', NULL),
(223, 20, 182, 'Tbs Tranexamic', 11, 1500, 0, 'pain', 1, '2025-08-16 20:43:30', NULL),
(224, 20, 182, 'Tbs Brustan', 10, 1000, 0, 'pain', 1, '2025-08-16 20:44:43', NULL),
(225, 20, 182, 'Cps Zycel 200mg', 45, 1000, 0, 'pain', 1, '2025-08-16 20:48:18', NULL),
(226, 20, 182, 'Tbs Nucocoxia', 27, 1500, 0, 'pain', 1, '2025-08-16 21:47:56', NULL),
(227, 20, 34, 'Syp Paracetamol', 1, 3000, 0, 'pain', 1, '2025-08-16 21:50:26', NULL),
(228, 37, 183, 'Tbs Bendric ', 480, 150, 0, 'hp', 1, '2025-08-16 21:54:50', NULL),
(229, 37, 183, 'Tbs Losacar H', 20, 800, 0, 'HP', 1, '2025-08-16 21:56:12', NULL),
(230, 37, 183, 'Tbs Nefedipine 20mg', 525, 100, 0, 'hp', 1, '2025-08-16 21:57:52', NULL),
(231, 37, 183, 'Tbs Propranalol', 70, 100, 0, 'hp', 1, '2025-08-16 21:59:11', NULL),
(232, 37, 183, 'Tbs Amlodopine 5mg', 85, 500, 0, 'hp', 1, '2025-08-16 22:01:06', NULL),
(233, 37, 183, 'Tbs Amlodopine 10mg', 30, 700, 0, 'hp', 1, '2025-08-16 22:02:28', NULL),
(234, 37, 183, 'Tbs Metaformin', 20, 100, 0, 'hp', 1, '2025-08-16 22:03:45', NULL),
(235, 37, 183, 'Tbs Gliben', 95, 100, 0, 'dia', 1, '2025-08-16 22:05:02', NULL),
(236, 37, 183, 'Tbs CBZ', 30, 200, 0, 'PSYC', 1, '2025-08-16 22:06:00', NULL),
(237, 37, 183, 'Tbs Pheno B', 340, 100, 0, 'PSYC', 1, '2025-08-16 22:07:08', NULL),
(238, 38, 184, 'Apacalis 20mg', 11, 10000, 0, 'mp', 1, '2025-08-17 20:25:33', NULL),
(239, 38, 184, 'Kamagra 100mg', 14, 5000, 0, 'mp', 1, '2025-08-17 20:26:41', NULL),
(240, 38, 184, 'Penegra 100mg', 18, 2000, 0, 'mp', 1, '2025-08-17 20:29:11', NULL),
(241, 38, 184, 'Penegra 50mg', 8, 1500, 0, 'mp', 1, '2025-08-17 20:30:24', NULL),
(242, 39, 185, 'Tbs Bisacodyl', 30, 100, 0, 'antid', 1, '2025-08-17 20:45:14', NULL),
(243, 39, 185, 'Syp Lactoluse', 2, 15000, 0, 'llax', 1, '2025-08-18 12:06:56', NULL),
(244, 39, 185, 'Enemax', 1, 25000, 0, 'lax', 1, '2025-08-18 12:08:37', NULL),
(245, 28, 186, 'Oral Rehydration', 8, 1000, 0, 'Diarr', 1, '2025-08-18 12:17:02', NULL),
(246, 28, 186, 'Zinc kid ', 0, 200, 0, 'anti d', 1, '2025-08-18 12:18:00', NULL),
(247, 29, 187, 'Menthoxyl', 500, 250, 0, 'cogh', 1, '2025-08-18 12:25:54', NULL),
(248, 29, 187, 'Zecuf', 8, 250, 0, 'flu', 1, '2025-08-18 12:26:50', NULL),
(249, 40, 188, 'Iodine', 0, 4000, 0, 'ty', 1, '2025-08-18 12:29:24', NULL),
(250, 40, 188, 'Hydrogen Peroxide', 3, 3000, 0, 'ants', 1, '2025-08-18 12:30:35', NULL),
(251, 40, 188, 'Crep Bandage big', 1, 6000, 0, 'crep', 1, '2025-08-18 12:32:37', NULL),
(252, 40, 188, 'Crep Bandage M', 0, 5000, 0, 'AN', 1, '2025-08-18 12:43:31', NULL),
(253, 40, 188, 'Crep Bandage s', 0, 3000, 0, 'crp', 1, '2025-08-18 12:49:01', NULL),
(254, 40, 188, 'Strapping Small', 9, 3000, 0, 'crp', 1, '2025-08-18 12:52:28', NULL),
(255, 40, 188, 'Linment', 4, 5000, 0, 'ty', 1, '2025-08-18 12:54:06', NULL),
(256, 40, 188, 'Cotton Big', 1, 13000, 0, 'cf', 1, '2025-08-18 12:55:38', NULL),
(257, 40, 188, 'Face masks', 2, 15000, 0, 'gy', 1, '2025-08-18 13:00:31', NULL),
(258, 41, 189, 'Fa Deodrants', 7, 6000, 0, 'jm', 1, '2025-08-18 15:36:51', NULL),
(259, 41, 189, 'Neivia Deodrant', 19, 10000, 0, 'gt', 1, '2025-08-18 15:38:16', NULL),
(260, 41, 189, 'Shower to Shower', 9, 6000, 0, 'gy', 1, '2025-08-18 15:42:38', NULL),
(261, 41, 189, 'Dove Deodrant', 1, 10000, 0, 'gy', 1, '2025-08-18 15:43:46', NULL),
(262, 41, 189, 'Rexona Deodrant', 1, 10000, 0, 'ty', 1, '2025-08-18 15:45:00', NULL),
(263, 41, 189, 'Yardely Deodrants', 2, 10000, 0, 'gy', 1, '2025-08-18 15:46:57', NULL),
(264, 41, 190, 'Crown Perfumes', 10, 9000, 0, 'fy', 1, '2025-08-18 15:49:31', NULL),
(265, 41, 190, 'Skala Men perfume', 4, 5000, 0, 'hy', 1, '2025-08-18 15:51:26', NULL),
(266, 41, 190, 'Body luxe mist', 2, 5000, 0, 'my', 1, '2025-08-18 15:53:59', NULL),
(267, 41, 190, 'Body Mists', 12, 17000, 0, 'gy', 1, '2025-08-18 15:56:22', NULL),
(268, 41, 190, 'Fog Sprays', 10, 17000, 0, 'gy', 1, '2025-08-18 15:57:45', NULL),
(269, 41, 190, 'Rasasi Sprays', 12, 12000, 0, 'yt', 1, '2025-08-18 16:00:47', NULL),
(270, 41, 190, 'Axe Spray', 4, 12000, 0, 'y', 1, '2025-08-18 16:03:10', NULL),
(271, 41, 190, 'Estiara Sprays', 7, 12000, 0, 'gy', 1, '2025-08-18 16:07:12', NULL),
(272, 41, 190, 'Sterling Sprays', 6, 12000, 0, 'yt', 1, '2025-08-18 16:08:50', NULL),
(273, 41, 190, 'Chris Adam sprays', 7, 10000, 0, 'fy', 1, '2025-08-18 16:10:13', NULL),
(274, 41, 191, 'Diana lotion', 20, 4000, 0, 'gy', 1, '2025-08-18 16:15:58', NULL),
(275, 41, 191, 'Xtra White', 3, 5000, 0, 'fy', 1, '2025-08-18 16:16:57', NULL),
(276, 41, 191, 'Actiff Plus', 2, 5000, 0, 'hy', 1, '2025-08-18 16:18:15', NULL),
(277, 41, 191, 'Deprosson Liquid', 2, 5000, 0, 'fy', 1, '2025-08-20 08:54:38', NULL),
(278, 41, 191, 'Betasol Liquid', 2, 5000, 0, 'ty', 1, '2025-08-20 08:55:42', NULL),
(279, 41, 191, 'Betasol Cream', 3, 4000, 0, 'gy', 1, '2025-08-20 09:22:12', NULL),
(280, 41, 190, 'Foundation small', 7, 5000, 0, 'ty', 1, '2025-08-20 09:27:50', NULL),
(281, 41, 191, 'Lip stick', 9, 5000, 0, 'fy', 1, '2025-08-20 09:40:51', NULL),
(282, 41, 191, 'Lip Gloss', 5, 5000, 0, 'yh', 1, '2025-08-20 09:41:56', NULL),
(283, 41, 191, 'Vaselline Lip therapy M', 2, 10000, 0, 'met', 1, '2025-08-20 09:43:58', NULL),
(284, 41, 191, 'Vaselline Lip therapy P', 1, 5000, 0, 'GY', 1, '2025-08-20 09:44:54', NULL),
(285, 41, 191, 'Lip Balm', 2, 2000, 0, 'ty', 1, '2025-08-20 09:45:46', NULL),
(286, 41, 191, 'Smoth and Clear gel', 2, 5000, 0, 'ty', 1, '2025-08-20 09:47:08', NULL),
(287, 41, 191, 'Lemovate creams', 1, 5000, 0, 'ty', 1, '2025-08-20 09:48:08', NULL),
(288, 41, 191, 'Hand Cream', 3, 6000, 0, 'ty', 1, '2025-08-20 09:50:44', NULL),
(289, 41, 191, 'Sun Block cream', 2, 20000, 0, 'ty', 1, '2025-08-20 09:52:55', NULL),
(290, 41, 191, 'Nisa Hair revomal S', 1, 3000, 0, 'GY', 1, '2025-08-20 09:54:03', NULL),
(291, 41, 191, 'Nisa Hair revomal big', 1, 9000, 0, 'ty', 1, '2025-08-20 09:55:15', NULL),
(292, 41, 192, 'Colgate Herbal B', 1, 7000, 0, 'TY', 1, '2025-08-20 09:59:49', NULL),
(293, 36, 192, 'Colgate Herbal M', 3, 4500, 0, 'GY', 1, '2025-08-20 10:00:58', NULL),
(294, 41, 192, 'Colgate Herbal S', 0, 3000, 0, 'TY', 1, '2025-08-20 10:02:03', NULL),
(295, 41, 192, 'Colgate Maximum CavityB', 4, 7000, 0, 'YT', 1, '2025-08-20 10:06:22', NULL),
(296, 41, 192, 'Colgate Maximum Cavity M', 3, 4500, 0, 'TY', 1, '2025-08-20 10:07:36', NULL),
(297, 41, 192, 'Colgate Charcol B', 2, 8000, 0, 'TY', 1, '2025-08-20 10:08:59', NULL),
(298, 41, 192, 'Colgate Charcol S', 2, 3000, 0, 'TY', 1, '2025-08-20 10:09:58', NULL),
(299, 41, 193, 'Dettol Soap B', 5, 7000, 0, 'TY', 1, '2025-08-20 10:12:27', NULL),
(300, 41, 193, 'Dettol Soap S', 5, 4000, 0, 'TY', 1, '2025-08-20 10:13:19', NULL),
(301, 41, 193, 'Dettol liquid M', 2, 8000, 0, 'TY', 1, '2025-08-20 10:14:17', NULL),
(302, 41, 193, 'Karambole Soap', 9, 6000, 0, 'ty', 1, '2025-08-20 10:15:52', NULL),
(303, 41, 193, 'Imperial Soap', 8, 5000, 0, 'ty', 1, '2025-08-20 10:17:20', NULL),
(304, 41, 193, 'Cusson Baby Soap', 3, 4000, 0, 'ty', 1, '2025-08-20 10:18:35', NULL),
(305, 41, 193, 'Johson Baby soap', 0, 4000, 0, 'ty', 1, '2025-08-20 10:19:37', NULL),
(306, 41, 193, 'Geisha Black B', 5, 5500, 0, 'TY', 1, '2025-08-20 10:20:55', NULL),
(307, 41, 193, 'Geisha Black S', 5, 3500, 0, 'TY', 1, '2025-08-20 10:21:56', NULL),
(308, 41, 193, 'Asante Papaya Soap', 2, 6000, 0, 'ty', 1, '2025-08-20 10:23:05', NULL),
(309, 41, 193, 'Ballet Soap', 3, 4000, 0, 'ty', 1, '2025-08-20 10:24:11', NULL),
(310, 41, 193, 'Black Seed soap', 1, 10000, 0, 'ty', 1, '2025-08-20 10:25:38', NULL),
(311, 41, 193, 'Kojic Papaya soap', 1, 10000, 0, 'ty', 1, '2025-08-20 10:26:48', NULL),
(312, 41, 193, 'Geisha Mix', 6, 4000, 0, 'ty', 1, '2025-08-20 10:28:28', NULL),
(313, 41, 193, 'Dove Soap', 2, 8000, 0, 'ty', 1, '2025-08-20 10:29:14', NULL),
(314, 41, 193, 'Dove Shower gel B', 0, 25000, 0, 'ty', 1, '2025-08-20 10:30:53', NULL),
(315, 41, 193, 'Dove Shower gel S', 0, 2000, 0, 'TY', 1, '2025-08-20 10:31:43', NULL),
(316, 41, 194, 'Johson Baby oil M', 2, 13000, 0, 'TY', 1, '2025-08-20 13:00:00', NULL),
(317, 41, 194, 'Johson Baby oil S', 1, 8000, 0, 'TY', 1, '2025-08-20 13:01:20', NULL),
(318, 41, 194, 'Cussons Baby oil', 2, 8000, 0, 'ty', 1, '2025-08-20 13:02:37', NULL),
(319, 41, 194, 'Ballet Baby oil', 0, 10000, 0, 'fg', 1, '2025-08-20 13:03:44', NULL),
(320, 41, 194, 'Vaselline Body Oil', 2, 45000, 0, 'hu', 1, '2025-08-20 13:04:58', NULL),
(321, 41, 194, 'Tummeric Body oil M', 1, 25000, 0, 'GY', 1, '2025-08-20 13:06:27', NULL),
(322, 41, 194, 'Tummeric Body oil S', 1, 18000, 0, 'TY', 1, '2025-08-20 13:07:27', NULL),
(323, 41, 194, 'Olive Oil B', 1, 15000, 0, 'TY', 1, '2025-08-20 13:08:38', NULL),
(324, 41, 194, 'Fresco Body oil', 3, 5000, 0, 'gy', 1, '2025-08-20 13:10:13', NULL),
(325, 41, 194, 'Latago Body oil', 0, 5000, 0, 'ty', 1, '2025-08-20 13:11:09', NULL),
(326, 41, 194, 'Rwanda Glycerine', 9, 2000, 0, 'ty', 1, '2025-08-20 13:12:51', NULL),
(327, 41, 187, 'Medicare Glycerine', 5, 2500, 0, 'ty', 1, '2025-08-20 13:14:13', NULL),
(328, 41, 194, 'Skala Glycerines', 7, 2500, 0, 'ty', 1, '2025-08-20 13:15:34', NULL),
(329, 41, 194, 'Body luxe Aloevera glycrine', 6, 2500, 0, 'xc', 1, '2025-08-20 13:17:00', NULL),
(330, 41, 194, 'Coconut Oil', 1, 2000, 0, 'rt', 1, '2025-08-20 13:18:03', NULL),
(331, 41, 195, 'Amara Men M', 4, 10000, 0, 'TY', 1, '2025-08-20 13:28:47', NULL),
(332, 41, 195, 'Amara Men Grey S', 2, 6000, 0, 'TY', 1, '2025-08-20 13:31:14', NULL),
(333, 41, 195, 'Amara Men Blue S', 1, 5500, 0, 'TY', 1, '2025-08-20 13:33:00', NULL),
(334, 41, 195, 'Amara Lotions mix M', 12, 10000, 0, 'TY', 1, '2025-08-20 13:39:25', NULL),
(335, 41, 195, 'Amara Lotions mix S', 5, 5500, 0, 'TY', 1, '2025-08-20 13:40:44', NULL),
(336, 41, 195, 'Vaselline Lotions B', 7, 15000, 0, 'YU', 1, '2025-08-20 13:47:58', NULL),
(337, 41, 195, 'Vaselline Lotions S mix', 4, 9000, 0, 'yu', 1, '2025-08-20 13:52:41', NULL),
(338, 41, 195, 'Neivia Men Lotions', 4, 20000, 0, 'u', 1, '2025-08-20 13:56:03', NULL),
(339, 41, 195, 'Nivea Lotions B mix', 4, 20000, 0, 'ty', 1, '2025-08-20 16:21:10', NULL),
(340, 41, 195, 'Nivea Lotions S mix', 3, 12000, 0, 'JNF', 1, '2025-08-20 16:27:28', NULL),
(341, 41, 195, 'Rubee Lotion B', 3, 20000, 0, 'GY', 1, '2025-08-20 16:30:03', NULL),
(342, 41, 195, 'Rubee M', 3, 8000, 0, 'TY', 1, '2025-08-20 16:31:06', NULL),
(343, 41, 195, 'Rubee S', 2, 5000, 0, 'TY', 1, '2025-08-20 16:33:53', NULL),
(344, 41, 195, 'Rinju Lotion B', 2, 23000, 0, 'TY', 1, '2025-08-20 16:35:50', NULL),
(345, 41, 195, 'Rinju Lotion M', 2, 8000, 0, 'TY', 1, '2025-08-20 16:37:24', NULL),
(346, 41, 195, 'Rinju Lotion S', 1, 6000, 0, 'RY', 1, '2025-08-20 16:39:40', NULL),
(347, 41, 195, 'Garlic Lotion', 0, 8000, 0, 'ty', 1, '2025-08-20 16:40:42', NULL),
(348, 41, 195, 'Body luxe Lotion', 3, 8000, 0, 'ty', 1, '2025-08-20 16:43:55', NULL),
(349, 41, 195, 'Girl friend', 1, 8000, 0, 'hu', 1, '2025-08-20 16:46:08', NULL),
(350, 41, 195, 'Dove Lotion M', 1, 20000, 0, 'TY', 1, '2025-08-20 16:47:41', NULL),
(351, 41, 195, 'Imperial Lotions', 4, 15000, 0, 'gy', 1, '2025-08-20 16:49:18', NULL),
(352, 41, 195, 'Vestline Aloevera B', 3, 7000, 0, 'GY', 1, '2025-08-20 16:53:15', NULL),
(353, 41, 195, 'Verseman Lotion', 3, 15000, 0, 'ty', 1, '2025-08-20 16:54:17', NULL),
(354, 41, 195, 'Skala Lotions Mix', 6, 8000, 0, 'ty', 1, '2025-08-20 16:59:02', NULL),
(355, 41, 195, 'Light Up Lotion', 2, 25000, 0, 'hy', 1, '2025-08-20 17:00:13', NULL),
(356, 41, 195, 'Africare Lotion', 1, 8000, 0, 'ty', 1, '2025-08-20 17:01:15', NULL),
(357, 41, 195, 'Body Talk Lotion', 1, 10000, 0, 'ty', 1, '2025-08-20 17:02:32', NULL),
(358, 41, 195, 'Proud Player Lotion', 1, 8000, 0, 'yu', 1, '2025-08-20 17:03:52', NULL),
(359, 41, 196, 'Movit Body milk M', 1, 4000, 0, 'YU', 1, '2025-08-20 17:07:17', NULL),
(360, 41, 196, 'Victor Cream', 1, 5000, 0, 'ty', 1, '2025-08-20 17:08:20', NULL),
(361, 41, 196, 'Day and Night Cream', 4, 6000, 0, 'ty', 1, '2025-08-20 17:09:21', NULL),
(362, 41, 196, 'Honey Skin ', 3, 9000, 0, 'ty', 1, '2025-08-20 17:18:53', NULL),
(363, 41, 196, 'American Dream Cream', 1, 1, 0, 'ty', 1, '2025-08-20 17:45:18', NULL),
(364, 41, 196, 'Pretty Be Papaya Cream', 1, 17000, 0, 'ty', 1, '2025-08-20 17:46:36', NULL),
(365, 41, 196, 'Cosmo Body Cream', 1, 27000, 0, 'yu', 1, '2025-08-20 17:52:53', NULL),
(366, 41, 196, 'Pretty White B', 3, 15000, 0, 'TY', 1, '2025-08-20 17:58:24', NULL),
(367, 41, 196, 'Pretty White S', 2, 7000, 0, 'TY', 1, '2025-08-20 18:03:52', NULL),
(368, 41, 196, 'White Secret B', 2, 20000, 0, 'TY', 1, '2025-08-20 18:04:50', NULL),
(369, 41, 196, 'White Secret S', 2, 10000, 0, 'TY', 1, '2025-08-20 18:05:51', NULL),
(370, 41, 196, 'Perfect Glow B', 2, 20000, 0, 'VB', 1, '2025-08-20 18:07:31', NULL),
(371, 41, 196, 'Light Up Cream', 3, 13000, 0, 'ty', 1, '2025-08-20 18:12:58', NULL),
(372, 41, 196, 'Lemon Clear', 1, 10000, 0, 'ty', 1, '2025-08-20 18:13:47', NULL),
(373, 41, 196, 'Carrot Bio Plus B', 1, 15000, 0, 'TY', 1, '2025-08-20 18:19:03', NULL),
(374, 41, 196, 'Carrot Bio Plus S', 3, 8000, 0, 'TY', 1, '2025-08-20 18:20:08', NULL),
(375, 41, 196, 'Peu Claire', 3, 7000, 0, 'bh', 1, '2025-08-20 18:21:14', NULL),
(376, 41, 196, 'Paw paw S', 3, 7000, 0, 'FG', 1, '2025-08-20 18:22:22', NULL),
(377, 41, 196, 'Body Luxe Cream ', 3, 4000, 0, 'ty', 1, '2025-08-20 19:02:22', NULL),
(378, 41, 194, 'Pure White Cream S', 1, 10000, 0, 'TY', 1, '2025-08-20 19:03:31', NULL),
(379, 41, 196, 'Organic Olive oil B', 1, 10000, 0, 'TY', 1, '2025-08-20 19:05:46', NULL),
(380, 41, 196, 'Vestline Garlic Cream', 1, 4000, 0, 'bh', 1, '2025-08-20 19:07:31', NULL),
(381, 41, 196, 'Young and Only cream', 2, 5000, 0, 'ty', 1, '2025-08-20 19:10:08', NULL),
(382, 41, 196, 'Habib Cream', 2, 4000, 0, 'gy', 1, '2025-08-20 19:11:21', NULL),
(383, 41, 196, 'Vestline Lemon Cream', 4, 4000, 0, 'uh', 1, '2025-08-20 19:12:44', NULL),
(384, 41, 196, 'Skala Cream Mix', 6, 4000, 0, 'ty', 1, '2025-08-20 19:15:02', NULL),
(385, 41, 196, 'Glow Pink Cream', 6, 4000, 0, 'gy', 1, '2025-08-20 19:16:50', NULL),
(386, 41, 196, 'Glow Pink S', 3, 2000, 0, 'TY', 1, '2025-08-20 19:18:26', NULL),
(387, 41, 196, 'Miss Loy B', 0, 14000, 0, 'YU', 1, '2025-08-20 19:58:15', NULL),
(388, 41, 196, '55 Medix', 2, 45000, 0, 'hy', 1, '2025-08-20 19:59:21', NULL),
(389, 41, 196, 'Miss Loy M', 5, 8000, 0, 'GY', 1, '2025-08-20 20:00:26', NULL),
(390, 41, 196, 'Miss Loy S', 1, 6500, 0, 'TY', 1, '2025-08-20 20:02:05', NULL),
(391, 41, 197, 'Ballet Jelly Mix', 4, 10000, 0, 'bn', 1, '2025-08-20 20:09:09', NULL),
(392, 41, 197, 'Ballet Jelly S', 5, 5000, 0, 'BN', 1, '2025-08-20 21:16:05', NULL),
(393, 41, 197, 'Kyogero Herbal B', 2, 7000, 0, 'BN', 1, '2025-08-20 21:17:11', NULL),
(394, 41, 197, 'Kyogero Herbal M', 6, 5000, 0, 'VB', 1, '2025-08-20 21:18:05', NULL),
(395, 41, 197, 'Kyogero Herbal S', 0, 4000, 0, 'HN', 1, '2025-08-20 21:19:05', NULL),
(396, 41, 197, 'Family Care jelly', 2, 5000, 0, 'nh', 1, '2025-08-20 21:20:26', NULL),
(397, 41, 197, 'Young and Only jelly Mix M', 7, 5000, 0, 'YU', 1, '2025-08-20 21:22:58', NULL),
(398, 41, 197, 'Young and Only jelly Mix B', 3, 11000, 0, 'HY', 1, '2025-08-20 21:24:01', NULL),
(399, 41, 197, 'Johson Baby Jelly', 3, 7000, 0, 'bh', 1, '2025-08-20 21:25:22', NULL),
(400, 41, 197, 'Cussons Baby Jelly', 1, 6000, 0, 'gy', 1, '2025-08-20 21:26:31', NULL),
(401, 41, 197, 'Movit Herbal Jelly B', 5, 6000, 0, 'BH', 1, '2025-08-20 21:34:02', NULL),
(402, 41, 197, 'Movit Herbal Jelly M', 0, 3000, 0, 'BN', 1, '2025-08-20 21:35:14', NULL),
(403, 41, 197, 'Movit Herbal Jelly S', 3, 1500, 0, 'YU', 1, '2025-08-20 21:36:57', NULL),
(404, 41, 197, 'Baby Junior B', 2, 5000, 0, 'mm', 1, '2025-08-20 21:46:57', NULL),
(405, 41, 197, 'Baby Junior M', 0, 3000, 0, 'TY', 1, '2025-08-20 21:48:55', NULL),
(406, 41, 197, 'Africare Jelly B', 3, 10000, 0, 'YU', 1, '2025-08-20 21:51:36', NULL),
(407, 41, 197, 'Africare Jelly M', 4, 5000, 0, 'TY', 1, '2025-08-20 21:53:28', NULL),
(408, 41, 197, 'Africare Jelly S', 5, 2500, 0, 'BH', 1, '2025-08-20 21:54:35', NULL),
(409, 41, 197, 'Vaselline Jelly B Mix', 12, 10000, 0, 'hy', 1, '2025-08-20 21:56:12', NULL),
(410, 41, 197, 'Vaselline Jelly S Mix', 15, 5000, 0, 'HY', 1, '2025-08-20 21:58:24', NULL),
(411, 41, 197, 'Herbolene Jelly', 2, 8500, 0, 'nh', 1, '2025-08-20 23:20:12', NULL),
(412, 41, 197, 'Ntale Oitment', 3, 2500, 0, 'bh', 1, '2025-08-20 23:27:48', NULL),
(413, 41, 197, 'Mikazi Jelly B', 3, 5000, 0, 'Y', 1, '2025-08-21 09:15:54', NULL),
(414, 41, 197, 'Mikazi Jelly S', 3, 2000, 0, 'YT', 1, '2025-08-21 09:17:21', NULL),
(415, 41, 197, 'Movity baby Jelly S', 6, 1500, 0, 'TY', 1, '2025-08-21 09:19:13', NULL),
(416, 41, 198, 'Hair Spray B', 8, 14000, 0, 'YU', 1, '2025-08-21 09:22:18', NULL),
(417, 41, 198, 'Hair Spray M', 3, 10000, 0, 'YU', 1, '2025-08-21 09:25:46', NULL),
(418, 41, 198, 'Hair Spray S', 9, 6000, 0, 'YU', 1, '2025-08-21 09:30:26', NULL),
(419, 41, 198, 'Sofin free', 1, 12000, 0, 'ty', 1, '2025-08-21 09:31:55', NULL),
(420, 41, 198, 'Black Hair Shampoo', 9, 2000, 0, 'hj', 1, '2025-08-21 09:34:17', NULL),
(421, 41, 198, 'Pressol M', 3, 5000, 0, 'VB', 1, '2025-08-21 09:35:11', NULL),
(422, 41, 198, 'Pressol S', 1, 2000, 0, 'YT', 1, '2025-08-21 09:37:12', NULL),
(423, 41, 198, 'T-tree Hair', 1, 28000, 0, 'ty', 1, '2025-08-21 09:42:00', NULL),
(424, 41, 198, 'Venous Curl Activator B', 3, 15000, 0, 'TY', 1, '2025-08-21 09:46:50', NULL),
(425, 41, 198, 'Labelle Hair Food', 2, 5000, 0, 'ty', 1, '2025-08-21 09:52:37', NULL),
(426, 41, 198, 'Venous Curl Activator M', 2, 8000, 0, 'TY', 1, '2025-08-21 09:55:27', NULL),
(427, 41, 198, 'TCB Hair food', 2, 6000, 0, 'yu', 1, '2025-08-21 09:56:57', NULL),
(428, 41, 198, 'Venous Curl Activator S', 2, 5000, 0, 'TY', 1, '2025-08-21 09:58:25', NULL),
(429, 41, 198, 'Movit Sulfur', 4, 2000, 0, 'ty', 1, '2025-08-21 10:00:05', NULL),
(430, 41, 198, 'Radiant Hair Cream', 6, 2000, 0, 'ty', 1, '2025-08-21 10:02:04', NULL),
(431, 41, 198, 'Movit Hair', 7, 2000, 0, 'yt', 1, '2025-08-21 10:04:17', NULL),
(432, 41, 198, 'Vestline Hair Tonic', 2, 3000, 0, 'ty', 1, '2025-08-21 10:06:58', NULL),
(433, 41, 198, 'Venous Hair food', 1, 5000, 0, 'ty', 1, '2025-08-21 10:09:12', NULL),
(434, 41, 198, 'La belle Body Scrub', 2, 7000, 0, 'ty', 1, '2025-08-21 10:13:23', NULL),
(435, 41, 199, 'Coffe Scrub', 2, 15000, 0, 'yu', 1, '2025-08-21 10:14:36', NULL),
(436, 41, 199, 'Lafresh Scrub', 2, 15000, 0, 'ty', 1, '2025-08-21 10:15:31', NULL),
(437, 42, 31, 'lusaniya1', 0, 1000, 800, 'test product', 1, '2025-08-27 21:46:10', NULL);

/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `stock_reconciliations`
-- --------------------------------------------------------

LOCK TABLES `stock_reconciliations` WRITE;
/*!40000 ALTER TABLE `stock_reconciliations` DISABLE KEYS */;
INSERT INTO `stock_reconciliations` (`id`, `product_id`, `system_stock`, `physical_count`, `difference`, `reconciliation_date`, `status`, `notes`, `created_by`, `approved_by`, `approved_at`) VALUES
(1, 92, 2, 4, 2, '2025-09-08 18:18:31', 'pending', 'cc', 1, NULL, NULL),
(2, 388, 2, 2, 0, '2025-09-08 18:23:16', 'approved', '', 1, 1, '2025-09-08 15:41:24');

/*!40000 ALTER TABLE `stock_reconciliations` ENABLE KEYS */;
UNLOCK TABLES;

-- Dumping data for table `users`
-- --------------------------------------------------------

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `status`, `vcode`, `country`) VALUES
(1, 'Admin', 'admin@gmail.com', 'test1234', 'Master', 1, '1234flx786', 'Uganda'),
(24, 'Nathan Tugume', 'nathantugumee@gmail.com', '$2y$12$EV3ovjO4EGc1pHSJVQhzne3qgqOXaMFGNKx5axCNbp74EPnddZAh.', 'User', 1, 'rh3q8owA&n$pA1R', 'Uganda');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

-- Migrations Table
-- --------------------------------------------------------

-- Table structure for table `migrations`
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` varchar(255) NOT NULL,
  `description` text,
  `applied_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `migrations`
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `description`, `applied_at`) VALUES
('001_add_expiry_date_to_products', 'Add expiry_date field to products table', '2025-09-08 15:44:12'),
('002_add_status_to_users', 'Add status field to users table', '2025-09-08 15:45:26'),
('003_create_customer_payments_table', 'Create customer_payments table', '2025-09-08 15:45:26'),
('004_create_stock_reconciliations_table', 'Create stock_reconciliations table', '2025-09-08 18:17:47'),
('005_add_created_at_to_products', 'Add created_at timestamp to products table', '2025-09-08 15:45:26'),
('006_update_orders_payment_fields', 'Ensure orders table has proper payment fields', '2025-09-08 15:45:29');

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

-- Triggers
-- --------------------------------------------------------

-- No triggers found

-- Views
-- --------------------------------------------------------

-- No views found

-- Functions
-- --------------------------------------------------------

-- No functions found

-- Procedures
-- --------------------------------------------------------

-- No procedures found

-- Export completed
-- --------------------------------------------------------

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

COMMIT;
-- End of export
