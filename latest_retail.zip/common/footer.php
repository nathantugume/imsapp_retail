</div>
<br>
<div style="background:#273c75; width: 100%; height: 30px; line-height: 30px; text-align: center; border-radius: 2px;color: white;">
	<p>All Rights Reserved @ 2025 Mini Price Hardware </p>
</div>
</body>
</html>